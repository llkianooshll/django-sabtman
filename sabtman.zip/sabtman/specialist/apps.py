from django.apps import AppConfig


class SpecialistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'specialist'
