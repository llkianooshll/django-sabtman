from django.db import models
from django.utils import timezone
from datetime import timedelta

class TodoList(models.Model):
    title = models.CharField(max_length=255)
    name = models.CharField(max_length=100)
    time = models.TimeField()
    created_at = models.DateTimeField(auto_now_add=True)

    def is_expired(self):
        return timezone.now() >= self.created_at + timedelta(hours=24)

    def __str__(self):
        return f"{self.title} - {self.name}"

    class Meta:
        verbose_name = "Todo List"
        verbose_name_plural = "Todo Lists"