from django.urls import path
from .views import SpecialistDashboard,TodoListView,TodoListDeleteView,SpecialistRequestsListView,RequestDetailView,SpecialistTicketListView,SpecialistTicketDetailView,SpecialistRequestDocumentsListView,SpecialistDocumentApproveView,SpecialistDocumentRejectView,SpecialistRequestDocumentsCheckedListView

urlpatterns = [
    path('dashboard/', SpecialistDashboard.as_view(), name='specialist-dashboard'),
    path('todolist/', TodoListView.as_view(), name='todolist-list-create'),
    path('todolist/<int:pk>/', TodoListDeleteView.as_view(), name='todolist-delete'),
    path('requests/', SpecialistRequestsListView.as_view(), name='specialist-requests'),
    path('requests/<int:pk>/', RequestDetailView.as_view(), name='request-detail'),
    path('tickets/', SpecialistTicketListView.as_view(), name='specialist-ticket-list'),
    path('tickets/<int:pk>/', SpecialistTicketDetailView.as_view(), name='specialist-ticket-detail'),
    path('documents/', SpecialistRequestDocumentsListView.as_view(), name='specialist-documents-list'),
    path('documents/<int:pk>/approve/', SpecialistDocumentApproveView.as_view(), name='specialist-document-approve'),
    path('documents/<int:pk>/reject/', SpecialistDocumentRejectView.as_view(), name='specialist-document-reject'),
    path('documents/checked/', SpecialistRequestDocumentsCheckedListView.as_view(), name='specialist-documents-checked-list'),
]