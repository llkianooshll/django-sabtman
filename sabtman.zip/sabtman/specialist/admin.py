from django.contrib import admin
from .models import TodoList

admin.site.register(TodoList)
