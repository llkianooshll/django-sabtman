from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from authentication.permissions import IsExpert
from user_requests.models import UserRequest,Document
from tickets.models import Ticket, TicketMessage
from users.models import Profile,Notifications
from rest_framework import generics,pagination,status,filters
from rest_framework.generics import RetrieveAPIView
from django.utils import timezone
from datetime import timedelta
from .models import TodoList
from .serializers import TodoListSerializer
from user_requests.serializers import UserRequestSerializer,DocumentSerializer
from tickets.models import Ticket, TicketMessage
from tickets.serializers import TicketSerializer, TicketMessageSerializer
from django.db import models
from django.db.models import Q
from django.shortcuts import get_object_or_404

class SpecialistDashboard(APIView):
    permission_classes = [IsAuthenticated, IsExpert]


    def get(self, request):
        user = request.user

        # بررسی اینکه کاربر نقش کارشناس دارد
        if user.role != 'expert':
            return Response({'error': 'Access denied. This dashboard is only for specialists.'}, status=403)

        # شمارش درخواست‌های در حال بررسی
        active_requests_count = UserRequest.objects.filter(service__user=user, status='active').count()

        # شمارش درخواست‌های تکمیل شده
        completed_requests_count = UserRequest.objects.filter(service__user=user, status='completed').count()

        # شمارش تیکت‌های باز
        open_tickets_count = Ticket.objects.filter(user=user, status='open').count()

        # دریافت میانگین امتیاز از پروفایل
        profile = Profile.objects.filter(user=user).first()
        average_rate = profile.average_rate if profile else None

        # دریافت اطلاعات درخواست‌هایی که متعلق به کارشناس هستند
        requests = UserRequest.objects.filter(service__user=user).values(
            'id',
            'status',
            'created_at',
            'updated_at',
            'user__username',
            'category__name'
        )[:4]

        # دریافت سه پیام اخیر از سه درخواست متفاوت
        recent_messages = []
        user_requests = UserRequest.objects.filter(service__user=user).prefetch_related('messages')[:3]
        for user_request in user_requests:
            message = user_request.messages.order_by('-created_at').first()
            if message:
                recent_messages.append({
                    'username': message.sender.username,
                    'updated_at': message.created_at,
                    'message': message.message,
                })

        # دریافت آخرین تیکت‌ها و پیام‌های مرتبط
        tickets = Ticket.objects.filter(user=user).order_by('-created_at')[:5]
        tickets_data = []
        for ticket in tickets:
            messages = TicketMessage.objects.filter(ticket=ticket).order_by('created_at')
            tickets_data.append({
                'ticket': {
                    'id': ticket.id,
                    'subject': ticket.subject,
                    'status': ticket.status,
                    'created_at': ticket.created_at,
                },
                'messages': [
                    {
                        'sender': message.sender.username,
                        'message': message.message,
                        'created_at': message.created_at,
                    }
                    for message in messages
                ]
            })

        # محاسبه درصد درخواست‌های تکمیل شده
        total_requests_count = UserRequest.objects.filter(service__user=user).count()
        if total_requests_count > 0:
            completed_requests_percent = int((completed_requests_count / total_requests_count) * 100)
        else:
            completed_requests_percent = 0

        # محاسبه درصد رضایت مشتری بر اساس average_rate (فرض بر این است که از 5 است)
        if average_rate:
            customer_satisfaction_percent = int((float(average_rate) / 5) * 100)
        else:
            customer_satisfaction_percent = 0

        # محاسبه میانگین اختلاف زمانی اولین پیام کاربر و اولین پیام کارشناس در هر درخواست و تبدیل به درصد
        response_times = []
        user_requests_with_messages = UserRequest.objects.filter(service__user=user).prefetch_related('messages')
        for req in user_requests_with_messages:
            messages = req.messages.order_by('created_at')
            first_user_msg = messages.filter(sender__role='user').first()
            first_expert_msg = messages.filter(sender__role='expert').first()
            if first_user_msg and first_expert_msg:
                diff = (first_expert_msg.created_at - first_user_msg.created_at).total_seconds() / 60  # دقیقه
                if diff >= 0:
                    response_times.append(diff)
        if response_times:
            avg_response_min = sum(response_times) / len(response_times)
            # درصد پاسخگویی: زیر 60 دقیقه = 100٪، 60 تا 180 دقیقه = 80٪، 180 تا 360 دقیقه = 60٪، بیشتر = 40٪
            if avg_response_min <= 60:
                avg_response_percent = 100
            elif avg_response_min <= 180:
                avg_response_percent = 80
            elif avg_response_min <= 360:
                avg_response_percent = 60
            else:
                avg_response_percent = 40
        else:
            avg_response_percent = 0

        # آماده‌سازی داده‌ها برای پاسخ
        data = {
            'active_requests': active_requests_count,
            'completed_requests': completed_requests_count,
            'open_tickets': open_tickets_count,
            'average_rate': average_rate,
            'requests': list(requests),
            'recent_messages': recent_messages,
            'tickets': tickets_data,
            'performance': {
                'completed_requests_percent': completed_requests_percent,
                'customer_satisfaction_percent': customer_satisfaction_percent,
                'avg_response_percent': avg_response_percent,
            }
        }

        return Response(data, status=200)
    

class TodoListView(generics.ListCreateAPIView):
    queryset = TodoList.objects.all()
    serializer_class = TodoListSerializer
    permission_classes = [IsAuthenticated,IsExpert]

    def get_queryset(self):
        # فقط آیتم‌هایی که منقضی نشده‌اند را نمایش بده
        expire_time = timezone.now() - timedelta(hours=24)
        return TodoList.objects.filter(created_at__gte=expire_time)

class TodoListDeleteView(generics.DestroyAPIView):
    queryset = TodoList.objects.all()
    serializer_class = TodoListSerializer
    permission_classes = [IsAuthenticated,IsExpert]
# صفحه‌بندی پیش‌فرض DRF
class StandardResultsSetPagination(pagination.PageNumberPagination):
    page_size = 10
    page_size_query_param = 'page_size'
    max_page_size = 100


# ویو برای نمایش ریکویست‌های متعلق به کارشناس جاری با صفحه‌بندی و فقط فیلدهای مورد نیاز

class SpecialistRequestsListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, IsExpert]
    pagination_class = StandardResultsSetPagination
    filter_backends = [filters.SearchFilter]
    search_fields = ['user__username', 'category__name', 'status']  # فیلدهای قابل جستجو

    def get_queryset(self):
        user = self.request.user
        queryset = UserRequest.objects.filter(service__user=user).select_related('user', 'category')

        search_query = self.request.query_params.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(user__username__icontains=search_query) |
                Q(category__name__icontains=search_query) |
                Q(status__icontains=search_query)
            )

        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        results = [
            {
                'id': req.id,
                'status': req.status,
                'created_at': req.created_at,
                'updated_at': req.updated_at,
                'user__username': req.user.username,
                'category__name': req.category.name if req.category else None
            }
            for req in page
        ]
        return self.get_paginated_response(results)

class RequestDetailView(RetrieveAPIView):
    queryset = UserRequest.objects.all().select_related('user', 'category', 'service').prefetch_related('messages__sender')
    serializer_class = UserRequestSerializer
    permission_classes = [IsAuthenticated, IsExpert]

    def get_object(self):
        obj = super().get_object()
        user = self.request.user
        # بررسی وجود سرویس و مالکیت کارشناس
        if not obj.service or obj.service.user != user:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied("شما اجازه مشاهده این درخواست را ندارید یا این درخواست سرویس معتبر ندارد.")
        return obj

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        messages = instance.messages.all().order_by('created_at')
        messages_data = [
            {
                'id': msg.id,
                'sender': msg.sender.username,
                'message': msg.message,
                'created_at': msg.created_at,
            }
            for msg in messages
        ]
        data = self.get_serializer(instance).data
        data['messages'] = messages_data
        return Response(data)

class SpecialistTicketListView(generics.ListAPIView):
    """
    نمایش لیست تیکت‌های مربوط به کارشناس (هم به عنوان فرستنده و هم گیرنده)
    """
    serializer_class = TicketSerializer
    permission_classes = [IsAuthenticated, IsExpert]
    pagination_class = StandardResultsSetPagination
    filter_backends = [filters.SearchFilter]
    search_fields = ['subject', 'messages__content', 'user__username', 'recipient__username']

    def get_queryset(self):
        user = self.request.user
        queryset = Ticket.objects.filter(
            Q(user=user) | Q(recipient=user)
        ).order_by('-created_at')

        search_query = self.request.query_params.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(subject__icontains=search_query) |
                Q(messages__content__icontains=search_query) |
                Q(user__username__icontains=search_query) |
                Q(recipient__username__icontains=search_query)
            ).distinct()

        return queryset


class SpecialistTicketDetailView(generics.RetrieveAPIView):
    """
    نمایش جزییات یک تیکت به همراه پیام‌های آن
    فقط اگر کارشناس یکی از طرفین تیکت باشد.
    """
    serializer_class = TicketSerializer
    permission_classes = [IsAuthenticated, IsExpert]
    queryset = Ticket.objects.all().select_related('user', 'recipient')

    def get_object(self):
        obj = super().get_object()
        user = self.request.user
        # فقط اگر کارشناس یکی از طرفین تیکت باشد اجازه مشاهده دارد
        if obj.user != user and obj.recipient != user:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied("شما اجازه مشاهده این تیکت را ندارید.")
        return obj

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        messages = TicketMessage.objects.filter(ticket=instance).select_related('sender').order_by('created_at')
        messages_data = TicketMessageSerializer(messages, many=True).data
        data = self.get_serializer(instance).data
        data['messages'] = messages_data
        return Response(data)


class SpecialistRequestDocumentsListView(generics.ListAPIView):
    """
    نمایش مدارک ارسال شده برای ریکویست‌هایی که متعلق به کارشناس جاری است
    """
    permission_classes = [IsAuthenticated, IsExpert]
    serializer_class = DocumentSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['title', 'status', 'request__user__username']

    def get_queryset(self):
        user = self.request.user
        queryset = Document.objects.filter(
            request__service__user=user
        ).select_related('request', 'request__user')

        search_query = self.request.query_params.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(title__icontains=search_query) |
                Q(status__icontains=search_query) |
                Q(request__user__username__icontains=search_query)
            )

        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        results = [
            {
                'id': doc.id,
                'title': doc.title,
                'status': doc.get_status_display() if hasattr(doc, 'get_status_display') else doc.status,
                'username': doc.request.user.username,
                'file': doc.file.url if doc.file else None,
                'request': doc.request.id,
                'created_at': doc.created_at,
            }
            for doc in queryset
        ]
        return Response(results)


class SpecialistDocumentApproveView(APIView):
    """
    تایید کردن مدرک توسط کارشناس (تغییر وضعیت به 'approved')
    """
    permission_classes = [IsAuthenticated, IsExpert]

    def post(self, request, pk):
        document = get_object_or_404(Document.objects.select_related('request__service'), pk=pk)
        user = request.user
        if not document.request.service or document.request.service.user != user:
            return Response({'detail': 'شما اجازه تغییر این مدرک را ندارید.'}, status=status.HTTP_403_FORBIDDEN)
        if document.status == 'confirmed':
            return Response({'detail': 'این مدرک قبلاً تایید شده است.'}, status=status.HTTP_400_BAD_REQUEST)
        document.status = 'confirmed'
        Notifications.objects.create(
            user=document.request.user,
            title="تغییر وضعیت مدرک",
            message=f"مدرک {document.title} شما توسط کارشناس تایید شد"
        )
        document.save()
        return Response({'detail': 'مدرک با موفقیت تایید شد.'})

class SpecialistDocumentRejectView(APIView):
    """
    رد کردن مدرک توسط کارشناس (تغییر وضعیت به 'rejected')
    """
    permission_classes = [IsAuthenticated, IsExpert]

    def post(self, request, pk):
        document = get_object_or_404(Document.objects.select_related('request__service'), pk=pk)
        user = request.user
        if not document.request.service or document.request.service.user != user:
            return Response({'detail': 'شما اجازه تغییر این مدرک را ندارید.'}, status=status.HTTP_403_FORBIDDEN)
        if document.status == 'rejected':
            return Response({'detail': 'این مدرک قبلاً رد شده است.'}, status=status.HTTP_400_BAD_REQUEST)
        document.status = 'rejected'
        Notifications.objects.create(
            user=document.request.user,
            title="تغییر وضعیت مدرک",
            message=f"مدرک {document.title} شما توسط کارشناس رد شد"
        )
        document.s
        document.save()
        return Response({'detail': 'مدرک با موفقیت رد شد.'})
    
class SpecialistRequestDocumentsCheckedListView(generics.ListAPIView):
    """
    نمایش مدارک ارسال شده برای ریکویست‌هایی که متعلق به کارشناس جاری است
    و وضعیت آن‌ها درحال بررسی (pending) نباشد.
    """
    permission_classes = [IsAuthenticated, IsExpert]
    serializer_class = DocumentSerializer

    def get_queryset(self):
        user = self.request.user
        return Document.objects.filter(
            request__service__user=user
        ).exclude(status='pending').select_related('request', 'request__user')

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        results = [
            {
                'id': doc.id,
                'title': doc.title,
                'status': doc.get_status_display() if hasattr(doc, 'get_status_display') else doc.status,
                'username': doc.request.user.username,
                'file': doc.file.url if doc.file else None,
                'request': doc.request.id,
                'created_at': doc.created_at,
            }
            for doc in queryset
        ]
        return Response(results)