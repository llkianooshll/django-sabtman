from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Ticket,TicketMessage
from .serializers import TicketSerializer,TicketMessageSerializer
from users.models import Notifications

class TicketListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # دریافت تیکت‌های کاربر
        tickets = Ticket.objects.filter(user=request.user)
        serializer = TicketSerializer(tickets, many=True)
        return Response(serializer.data)

    def post(self, request):
        # ایجاد تیکت جدید
        serializer = TicketSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

class TicketMessageView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, ticket_id):
        try:
            ticket = Ticket.objects.get(id=ticket_id, user=request.user)
        except Ticket.DoesNotExist:
            return Response({'error': 'Ticket not found'}, status=404)

        # دریافت پیام‌های مرتبط با تیکت
        messages = TicketMessage.objects.filter(ticket=ticket).order_by('created_at')
        serializer = TicketMessageSerializer(messages, many=True)
        return Response(serializer.data)

    def post(self, request, ticket_id):
        try:
            ticket = Ticket.objects.get(id=ticket_id)
        except Ticket.DoesNotExist:
            return Response({'error': 'Ticket not found'}, status=404)

        serializer = TicketMessageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(ticket=ticket, sender=request.user)
            Notifications.objects.create(
                user=ticket.recipient,
                title="تیکت جدید",
                message=f"شما از {ticket.user} پیام جدید دریافت کردید"
            )
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
