from django.urls import path
from .views import TicketListView, TicketMessageView

urlpatterns = [
    path('', TicketListView.as_view(), name='ticket_list'),  # مشاهده و ایجاد تیکت
    path('<int:ticket_id>/messages/', TicketMessageView.as_view(), name='ticket_messages'),  # مشاهده و ارسال پیام
]