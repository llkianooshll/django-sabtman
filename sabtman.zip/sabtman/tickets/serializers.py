from rest_framework import serializers
from .models import Ticket, TicketMessage

class TicketSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username')  # نمایش نام کاربر
    recipient = serializers.ReadOnlyField(source='recipient.username')  # نمایش نام گیرنده
    status_display = serializers.CharField(source='get_status_display', read_only=True)  # نمایش وضعیت به صورت خوانا

    class Meta:
        model = Ticket
        fields = [
            'id', 'user', 'recipient', 'subject', 'status', 'status_display', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'user', 'recipient', 'status', 'created_at', 'updated_at']


class TicketMessageSerializer(serializers.ModelSerializer):
    sender = serializers.ReadOnlyField(source='sender.username')  # نمایش نام فرستنده

    class Meta:
        model = TicketMessage
        fields = ['id', 'ticket', 'sender', 'message', 'created_at']
        read_only_fields = ['id', 'ticket', 'sender', 'created_at']