from django.db import models
from django.conf import settings
from validators import ValidationError

class Ticket(models.Model):
    STATUS_CHOICES = [
        ('open', 'باز'),
        ('closed', 'بسته'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='tickets_sent'
    )  # فرستنده (همیشه کاربر عادی)
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='tickets_received',
        null=True, blank=True
    )
    subject = models.CharField(max_length=255)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='open')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def clean(self):
        # فقط کاربر عادی می‌تواند فرستنده باشد و فقط کارشناس یا پشتیبان گیرنده
        if self.user.role != 'user' or self.recipient.role not in ['expert', 'support']:
            raise ValidationError('Ticket must be between user and expert/support.')

    def __str__(self):
        return f"{self.subject} - {self.user.username} -> {self.recipient.username}"

class TicketMessage(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message by {self.sender.username} in {self.ticket.subject}"
