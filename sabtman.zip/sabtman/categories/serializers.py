from rest_framework import serializers
from .models import Category
class CategorySerializer(serializers.ModelSerializer):
    service_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = Category
        fields = ['id', 'name', 'created_at', 'service_count']  # اضافه کردن service_count به فیلدهای خروجی