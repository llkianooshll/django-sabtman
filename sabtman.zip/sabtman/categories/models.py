from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=255, unique=True, verbose_name="نام دسته‌بندی")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")

    def __str__(self):
        return self.name