from django.urls import path
from .views import CreateChatView, MessageListCreateView

urlpatterns = [
    path('', CreateChatView.as_view(), name='chat-list-create'),
    path('<int:chat_id>/messages/', MessageListCreateView.as_view(), name='message-list-create'),
]
