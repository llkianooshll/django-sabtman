from rest_framework import generics, permissions
from rest_framework.exceptions import PermissionDenied, NotFound
from .models import Chat, Message
from rest_framework.response import Response
from rest_framework.views import APIView,status
from .serializers import ChatSerializer, MessageSerializer
from rest_framework.permissions import IsAuthenticated
from authentication.models import CustomUser
from authentication.permissions import IsNotBlocked
from django.shortcuts import get_object_or_404
from users.models import Notifications


class CreateChatView(APIView):
    permission_classes = [IsAuthenticated,IsNotBlocked]

    def post(self, request):
        expert_id = request.data.get('expert_id')
        if not expert_id:
            return Response({'detail': 'expert_id الزامیست'}, status=400)

        user = request.user  # کاربر از توکن استخراج می‌شود

        # چک کنیم نقش کاربر درست است
        if user.role != 'user':
            return Response({'detail': 'فقط کاربران عادی می‌توانند چت را آغاز کنند.'}, status=403)

        try:
            expert = CustomUser.objects.get(id=expert_id, role='expert')
        except CustomUser.DoesNotExist:
            return Response({'detail': 'کارشناس یافت نشد.'}, status=404)

        chat, created = Chat.objects.get_or_create(user=user, expert=expert)

        return Response({
            'message': 'چت ایجاد شد' if created else 'چت قبلاً ایجاد شده بود',
            'chat_id': chat.id
        }, status=201)
    def get(self,request):
        user = request.user
        if user.role == 'user':
            chats = Chat.objects.filter(user=user)
            serializer = ChatSerializer(chats,many=True)
            return Response(serializer.data,status=status.HTTP_200_OK)
        if user.role == 'expert':
            chats = Chat.objects.filter(expert=user)
            serializer = ChatSerializer(chats,many=True)
            return Response(serializer.data,status=status.HTTP_200_OK)


class MessageListCreateView(generics.ListCreateAPIView):
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated,IsNotBlocked]

    def get_chat(self):
        return get_object_or_404(Chat, id=self.kwargs['chat_id'])

    def get_queryset(self):
        chat = self.get_chat()
        user = self.request.user
        if chat.user != user and chat.expert != user:
            raise PermissionDenied('شما اجازه دسترسی به این چت را ندارید.')
        return chat.messages.all().order_by('timestamp')

    def perform_create(self, serializer):
        chat = self.get_chat()
        user = self.request.user
        if chat.user != user and chat.expert != user:
            raise PermissionDenied('شما اجازه ارسال پیام در این چت را ندارید.')
        Notifications.objects.create(
            user=chat.expert,
            title="پیام جدید",
            message=f"شما از کاربر {chat.user.username} پیام جدید دریافت کرده اید"
        )
        serializer.save(chat=chat, sender=user)
