from django.urls import path
from .views import ProfileView,NotificationsDetailView,NotificationListView,ChangePasswordView,TransactionHistoryView,UserAcquisitionSourcesView,FollowUserView,UserFollowListView,UserDashboardView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('profile/',ProfileView.as_view(),name='profile'),
    path('notifications/',NotificationListView.as_view(),name='notifications'),
    path('notifications/<int:pk>/',NotificationsDetailView.as_view(),name='notification'),
    path('notifications/<int:pk>/read/',NotificationsDetailView.as_view(),name='notification_reading'),
    path('change-password/', ChangePasswordView.as_view(), name='change_password'),
    path('transactions/', TransactionHistoryView.as_view(), name='transaction_history'),
    path('acquisition-sources/', UserAcquisitionSourcesView.as_view(), name='user_acquisition_sources'),
    path('<int:user_id>/follow/', FollowUserView.as_view(), name='follow-user'),
    path('follow-list/', UserFollowListView.as_view(), name='follow-list'),
    path('dashboard/', UserDashboardView.as_view(), name='user-dashboard'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)