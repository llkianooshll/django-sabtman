from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework import status
from .models import Profile,Notifications,TransactionHistory,UserAcquisitionSources,Follow
from .serializers import ProfileSerializer,NotificationsSerializer,ChangePasswordSerializer,TransactionHistorySerializer
from authentication.permissions import IsPhoneVerified,IsNotBlocked,IsUser
from authentication.models import CustomUser
from tickets.models import Ticket,TicketMessage
from tickets.serializers import TicketMessageSerializer
from user_requests.models import UserRequest
from django.shortcuts import get_object_or_404
from management.models import SecurityLog,GlobalSecuritySettings

from django.utils import timezone
from datetime import timedelta
def clean_old_logs():
    now = timezone.now()
    if not hasattr(clean_old_logs, "_last_run") or (now - clean_old_logs._last_run).days >= 7:
        SecurityLog.objects.filter(timestamp__lt=now - timedelta(days=7)).delete()
        clean_old_logs._last_run = now
def clean_old_notifications():
    now = timezone.now()
    if not hasattr(clean_old_notifications, "_last_run") or (now - clean_old_notifications._last_run).days >= 1:
        Notifications.objects.filter(created_at__lt=now - timedelta(days=7)).delete()
        clean_old_notifications._last_run = now

class ProfileView(APIView):
    permission_classes = [IsAuthenticated,IsPhoneVerified,IsNotBlocked]

    def get(self, request):
        clean_old_notifications()
        try:
            profile = request.user.profile
        except Profile.DoesNotExist:
            return Response({'error': 'پروفایل برای این کاربر وجود ندارد.'}, status=404)

        serializer = ProfileSerializer(profile)
        return Response(serializer.data)
    def put(self, request):
        try:
            profile = request.user.profile
        except Profile.DoesNotExist:
            return Response({'error': 'پروفایل برای این کاربر وجود ندارد.'}, status=404)

        serializer = ProfileSerializer(profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            Notifications.objects.create(
                user=request.user,
                title="پروفایل آپدیت شد",
                message="پروفایل شما با موفقیت آپدیت شد!"
            )
            return Response(serializer.data)
        return Response(serializer.errors, status=400)
class NotificationListView(APIView):
    permission_classes = [IsAuthenticated,IsPhoneVerified,IsNotBlocked]
    def get(self,request):
        clean_old_notifications()
        try:
            notifications = Notifications.objects.filter(user = request.user)
            serializer = NotificationsSerializer(notifications,many=True)
            return Response(serializer.data)
        except Exception as e:
            return Response({"error":e})
class NotificationsDetailView(APIView):
    permission_classes = [IsAuthenticated,IsPhoneVerified,IsNotBlocked]
    def get(self,request,pk):
        try:
            notifications = Notifications.objects.get(pk=pk,user = request.user)
        except Notifications.DoesNotExist:
            return Response({'error':'Notification not found'},status=status.HTTP_404_NOT_FOUND)
        serializer = NotificationsSerializer(notifications)
        return Response(serializer.data)
    def put(self,request,pk):
        try:
            notification = Notifications.objects.get(pk=pk,user=request.user)
        except Notifications.DoesNotExist:
            return Response({'error':'notification not found'},status=status.HTTP_404_NOT_FOUND)
        notification.is_read = True
        notification.save()
        return Response({'message':'done!'})

class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated,IsPhoneVerified,IsNotBlocked]

    def put(self, request):
        serializer = ChangePasswordSerializer(data=request.data, context={'request': request})
        clean_old_logs()
        if serializer.is_valid():
            user = request.user
            user.set_password(serializer.validated_data['new_password'])
            user.save()
            Notifications.objects.create(
                user=user,
                title="تغییر زمر عبور",
                message="رمز عبور شما با موفقیت تغییر کرد!"
            )
            if GlobalSecuritySettings.track_user_activity:
                SecurityLog.objects.create(
                    user=user,
                    ip_address=request.META.get('REMOTE_ADDR', ''),
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    event_type="تغییر رمز عبور",
                    message="رمز عبور با موفقیت تغییر یافت.",
                    severity="warning"
                )

            return Response({'message': 'رمز عبور با موفقیت تغییر یافت.'}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    


class TransactionHistoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        transactions = TransactionHistory.objects.filter(user=request.user).order_by('-created_at')
        serializer = TransactionHistorySerializer(transactions, many=True)
        return Response(serializer.data)

class UserAcquisitionSourcesView(APIView):
    permission_classes = [IsAuthenticated]
    def put(self, request):
        # به‌روزرسانی منابع جذب کاربران
        sources, created = UserAcquisitionSources.objects.get_or_create(id=1)  # فرض می‌کنیم فقط یک رکورد وجود دارد
        data = request.data

        sources.google_ads += data.get("google_ads", 0)
        sources.organic_search += data.get("organic_search", 0)
        sources.social_media += data.get("social_media", 0)
        sources.referrals += data.get("referrals", 0)
        sources.others += data.get("others", 0)
        sources.save()

        return Response({'message': 'User acquisition sources updated successfully.'}, status=status.HTTP_200_OK)
    

class FollowUserView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request, user_id):
        target_user = get_object_or_404(CustomUser, id=user_id)
        if request.user.id == user_id:
            return Response({'error': 'you cannot follow this user'}, status=status.HTTP_400_BAD_REQUEST)
        if not target_user.can_be_followed():
            return Response({'error': 'This user cannot be followed.'}, status=status.HTTP_400_BAD_REQUEST)

        if not request.user.can_follow():
            return Response({'error': 'You do not have permission to follow users.'}, status=status.HTTP_400_BAD_REQUEST)

        if Follow.objects.filter(follower=request.user, following=target_user).exists():
            return Response({'error': 'You are already following this user.'}, status=status.HTTP_400_BAD_REQUEST)

        Follow.objects.create(follower=request.user, following=target_user)
        clean_old_notifications()
        Notifications.objects.create(
                user=target_user,
                title="فالور جدید!",
                message=f"{request.user.username} شما را فالو کرد"
            )
        # به‌روزرسانی تعداد فالوورها
        if hasattr(target_user, 'profile'):
            target_user.profile.follower_count += 1
            target_user.profile.save()

        return Response({'success': f'You are now following {target_user.username}.'}, status=status.HTTP_201_CREATED)

    def delete(self, request, user_id):
        target_user = get_object_or_404(CustomUser, id=user_id)

        follow_instance = Follow.objects.filter(follower=request.user, following=target_user).first()
        if not follow_instance:
            return Response({'error': 'You are not following this user.'}, status=status.HTTP_400_BAD_REQUEST)

        follow_instance.delete()

        # به‌روزرسانی تعداد فالوورها
        if hasattr(target_user, 'profile') and target_user.profile.follower_count > 0:
            target_user.profile.follower_count -= 1
            target_user.profile.save()

        return Response({'success': f'You have unfollowed {target_user.username}.'}, status=status.HTTP_200_OK)
    
class UserFollowListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        if user.role == 'user':
            # نمایش فالوینگ‌ها برای کاربران عادی
            following = user.following.all().values_list('following__username', flat=True)
            return Response({'following': list(following)}, status=status.HTTP_200_OK)

        elif user.role == 'expert':
            # نمایش فالوینگ‌ها و فالوورها برای کارشناسان
            following = user.following.all().values_list('following__username', flat=True)
            followers = user.followers.all().values_list('follower__username', flat=True)
            return Response({'following': list(following), 'followers': list(followers)}, status=status.HTTP_200_OK)

        return Response({'error': 'Invalid role.'}, status=status.HTTP_400_BAD_REQUEST)
    

class UserDashboardView(APIView):
    permission_classes = [IsUser,IsAuthenticated]

    def get(self, request):
        user = request.user

        # شمارش درخواست‌ها بر اساس وضعیت
        completed_requests_count = UserRequest.objects.filter(user=user, status='completed').count()
        pending_payment_requests_count = UserRequest.objects.filter(user=user, status='pending_payment').count()
        in_progress_requests_count = UserRequest.objects.filter(user=user, status='in_progress').count()

        # دریافت آخرین تیکت‌ها و پیام‌های مرتبط
        tickets = Ticket.objects.filter(user=user).order_by('-created_at')[:5]  # آخرین ۵ تیکت
        tickets_data = []
        for ticket in tickets:
            messages = TicketMessage.objects.filter(ticket=ticket).order_by('created_at')
            messages_serializer = TicketMessageSerializer(messages, many=True)
            tickets_data.append({
                'ticket': {
                    'id': ticket.id,
                    'subject': ticket.subject,
                    'status': ticket.status,
                    'recipient': ticket.recipient,
                    'created_at': ticket.created_at,
                },
                'messages': messages_serializer.data
            })

        # آماده‌سازی داده‌ها برای پاسخ
        data = {
            'requests': {
                'completed': completed_requests_count,
                'pending_payment': pending_payment_requests_count,
                'in_progress': in_progress_requests_count,
            },
            'tickets': tickets_data,
        }

        return Response(data, status=status.HTTP_200_OK)
