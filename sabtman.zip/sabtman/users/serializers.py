from rest_framework import serializers
from .models import Profile,Notifications,TransactionHistory


class ProfileSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username')
    class Meta:
        model = Profile
        fields = ['bio','user', 'avatar', 'email', 'address', 'created_at', 'updated_at','first_name','last_name','average_rate','completed_requests']
        read_only_fields = ['average_rate','completed_requests']
class NotificationsSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username') 
    class Meta:
        model = Notifications
        fields = ['id','user','title','message','is_read','created_at']
class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate_old_password(self, value):
        user = self.context['request'].user
        if not user.check_password(value):
            raise serializers.ValidationError("رمز عبور فعلی اشتباه است.")
        return value
    

class TransactionHistorySerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username')  # نمایش نام کاربر

    class Meta:
        model = TransactionHistory
        fields = ['id', 'user', 'transaction_type', 'amount', 'status', 'description', 'created_at', 'updated_at']
        read_only_fields = ['id', 'user', 'created_at', 'updated_at']
