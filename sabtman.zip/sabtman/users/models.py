from django.db import models
from django.contrib.auth.models import User
from django.conf import settings

class Profile(models.Model):
    first_name = models.CharField(max_length=30,blank=True,null=True)
    last_name = models.CharField(max_length=50,blank=True,null=True)
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile')
    bio = models.TextField(blank=True, null=True)  # بیوگرافی کاربر
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True) # تصویر پروفایل
    email = models.EmailField(blank=True, null=True)  # شماره تلفن
    address = models.CharField(max_length=255, blank=True, null=True)  # آدرس
    created_at = models.DateTimeField(auto_now_add=True)  # تاریخ ایجاد
    updated_at = models.DateTimeField(auto_now=True)  # تاریخ آخرین بروزرسانی
    average_rate = models.DecimalField(max_digits=3, decimal_places=2, blank=True, null=True, default=0.0)
    completed_requests = models.PositiveIntegerField(default=0)
    follower_count = models.PositiveIntegerField(default=0)
    def __str__(self):
        return self.user.username
class Notifications(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')  # تغییر به ForeignKey
    title = models.CharField(max_length=255)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} - {self.title}'
class TransactionHistory(models.Model):
    TRANSACTION_TYPES = [
        ('deposit', 'Deposit'), 
        ('withdraw', 'Withdraw'),
        ('payment', 'Payment'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='transactions')
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)  # مبلغ تراکنش
    status = models.CharField(max_length=20, choices=[('pending', 'Pending'), ('completed', 'Completed'), ('failed', 'Failed')], default='pending')
    description = models.TextField(blank=True, null=True)  # توضیحات تراکنش
    created_at = models.DateTimeField(auto_now_add=True)  # تاریخ ایجاد
    updated_at = models.DateTimeField(auto_now=True)  # تاریخ آخرین بروزرسانی

    def __str__(self):
        return f"{self.user.username} - {self.transaction_type} - {self.amount}"
    
class Follow(models.Model):
    follower = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='following')
    following = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='followers')
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.follower.username} follows {self.following.username}"
    class Meta:
        unique_together = ('follower', 'following')

from django.db import models

class UserAcquisitionSources(models.Model):
    google_ads = models.PositiveIntegerField(default=0, verbose_name="تبلیغات گوگل")
    organic_search = models.PositiveIntegerField(default=0, verbose_name="جستجوی ارگانیک")
    social_media = models.PositiveIntegerField(default=0, verbose_name="شبکه‌های اجتماعی")
    referrals = models.PositiveIntegerField(default=0, verbose_name="معرفی")
    others = models.PositiveIntegerField(default=0, verbose_name="سایر")

    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاریخ بروزرسانی")

    def __str__(self):
        return f"User Acquisition Sources (ID: {self.id})"