from django.contrib import admin
from .models import Profile,UserAcquisitionSources,Notifications,TransactionHistory,Follow

admin.site.register(Profile)
admin.site.register(UserAcquisitionSources)
admin.site.register(Notifications)
admin.site.register(TransactionHistory)
admin.site.register(Follow)
