from django.db import models
from django.conf import settings

class Transaction(models.Model):
    TRANSACTION_TYPES = [
        ('deposit', 'Deposit'),  # واریز
        ('withdraw', 'Withdraw'),  # برداشت
        ('payment', 'Payment'),  # پرداخت
    ]

    STATUS_CHOICES = [
        ('pending', 'Pending'),  # در انتظار
        ('completed', 'Completed'),  # تکمیل شده
        ('failed', 'Failed'),  # ناموفق
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='transaction_records')  # کاربر مرتبط با تراکنش
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)  # نوع تراکنش
    amount = models.DecimalField(max_digits=10, decimal_places=2)  # مبلغ تراکنش
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')  # وضعیت تراکنش
    description = models.TextField(blank=True, null=True)  # توضیحات تراکنش
    created_at = models.DateTimeField(auto_now_add=True)  # تاریخ ایجاد
    updated_at = models.DateTimeField(auto_now=True)  # تاریخ آخرین بروزرسانی

    def __str__(self):
        return f"{self.user.username} - {self.transaction_type} - {self.amount}"