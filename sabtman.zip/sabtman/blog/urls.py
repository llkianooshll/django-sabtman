from django.urls import path
from .views import PostListView, PostDetailView,PostUpdateDeleteView,CommentDeleteView,CategoryListView,CategoryCreate,CommentCreate,PostCreate,CategoryCreate,CommentPublishView,TopViewedPostsView,TopExpertsView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('posts/', PostListView.as_view(), name='post_list'),  # لیست و ایجاد پست‌ها
    path('posts/create/', PostCreate.as_view(), name='post_create'),  # لیست و ایجاد پست‌ها
    path('posts/<int:post_id>/', PostDetailView.as_view(), name='post_detail'),  # جزئیات پست و ارسال نظر
    path('posts/<int:post_id>/update-delete/', PostUpdateDeleteView.as_view(), name='post_update_delete'),
    path('comments/<int:comment_id>/delete/', CommentDeleteView.as_view(), name='comment_delete'),
    path('posts/<int:post_id>/comment/', CommentCreate.as_view(), name='comment_create'),
    path('categories/', CategoryListView.as_view(), name='category_list'),
    path('categories/create/', CategoryCreate.as_view(), name='category_create'),
    path('comments/<int:comment_id>/publish/', CommentPublishView.as_view(), name='comment_publish'),
    path('posts/top/', TopViewedPostsView.as_view(), name='top_posts'),
    path('top-experts/', TopExpertsView.as_view(), name='top-experts'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)