from rest_framework import serializers
from .models import Post, Comment
from categories.serializers import CategorySerializer
from categories.models import Category

class CommentSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username')

    class Meta:
        model = Comment
        fields = ['id', 'post', 'user', 'content', 'created_at','is_published']
        read_only_fields = ['id', 'post', 'user', 'created_at']

class PostSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)  # نمایش اطلاعات دسته‌بندی
    category_id = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all(), source='category', write_only=True)  # برای ایجاد یا ویرایش
    author = serializers.ReadOnlyField(source='author.username')
    class Meta:
        model = Post
        fields = ['id', 'title', 'content', 'author', 'category', 'category_id', 'image', 'created_at', 'updated_at', 'is_published', 'views','description']
        read_only_fields = ['author', 'views', 'created_at', 'updated_at']