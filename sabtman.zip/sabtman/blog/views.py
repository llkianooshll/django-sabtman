from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated,IsAuthenticatedOrReadOnly
from .models import Post
from categories.models import Category
from .serializers import PostSerializer,CommentSerializer
from categories.serializers import CategorySerializer
from authentication.permissions import IsAdmin,IsSeoExpert
from users.models import Profile,Notifications
from rest_framework import status
from django.db.models import Count
from django.db.models import Q

class PostListView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        search_query = request.query_params.get('search', '')
        user = request.user

        if user.is_authenticated and (user.role == 'seo_expert' or user.role == 'admin'):
            posts = Post.objects.all()
        else:
            posts = Post.objects.filter(is_published=True)

        if search_query:
            posts = posts.filter(
                Q(title__icontains=search_query) |
                Q(content__icontains=search_query) |
                Q(author__username__icontains=search_query)  # در صورت وجود چنین فیلدی
            )

        posts = posts.order_by('-created_at')
        serializer = PostSerializer(posts, many=True)
        return Response(serializer.data)


class PostCreate(APIView):
    def post(self, request):
        if((request.user.role == 'seo_expert')or(request.user.role == 'admin')):
            serializer = PostSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save(author=request.user)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        return Response({'detail':"شما به این قسمت دسترسی ندارید"})
    

class PostDetailView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]
    def get(self, request, post_id):
        try:
            post = Post.objects.get(id=post_id, is_published=True)
        except Post.DoesNotExist:
            return Response({'error': 'Post not found'}, status=404)
        post.views += 1
        post.save()
        # سریالایز کردن پست
        post_serializer = PostSerializer(post)

        # دریافت کامنت‌های مرتبط با پست
        if((request.user.role == 'seo_expert')or(request.user.role == 'admin')):
            comments = post.comments.all()  # فرض بر این است که related_name='comments' در مدل Comment تعریف شده است
        else:
            comments = post.comments.filter(is_published = True)
        comment_serializer = CommentSerializer(comments, many=True)

        # ترکیب داده‌های پست و کامنت‌ها
        data = {
            **post_serializer.data,
            "comments": comment_serializer.data
        }

        return Response(data, status=200)

class PostUpdateDeleteView(APIView):

    def put(self, request, post_id):
        if((request.user.role == 'seo_expert')or(request.user.role == 'admin')):
            try:
                post = Post.objects.get(id=post_id)
            except Post.DoesNotExist:
                return Response({'error': 'Post not found'}, status=404)

            serializer = PostSerializer(post, data=request.data, partial=True)  # partial=True برای آپدیت جزئی
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=200)
            return Response(serializer.errors, status=400)
        return Response({'detail':"شما به این قسمت دسترسی ندارید"})
    def delete(self, request, post_id):
        if((request.user.role == 'seo_expert')or(request.user.role == 'admin')):
            try:
                post = Post.objects.get(id=post_id)
            except Post.DoesNotExist:
                return Response({'error': 'Post not found'}, status=404)

            post.delete()
            return Response({'message': 'Post deleted successfully.'}, status=200)
        return Response({'detail':"شما به این قسمت دسترسی ندارید"})
from .models import Comment

class CommentDeleteView(APIView):

    def delete(self, request, comment_id):
        if((request.user.role == 'seo_expert')or(request.user.role == 'admin')):
            try:
                comment = Comment.objects.get(id=comment_id)
            except Comment.DoesNotExist:
                return Response({'error': 'Comment not found'}, status=404)

            comment.delete()
            return Response({'message': 'Comment deleted successfully.'}, status=200)
        return Response({'detail':"شما به این قسمت دسترسی ندارید"})
class CommentCreate(APIView):
    def post(self, request, post_id):
        try:
            post = Post.objects.get(id=post_id, is_published=True)
        except Post.DoesNotExist:
            return Response({'error': 'Post not found'}, status=404)

        serializer = CommentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(post=post, user=request.user)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)


class CategoryListView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        categories = Category.objects.annotate(post_count=Count('posts'))
        serializer = CategorySerializer(categories, many=True)

        # اضافه کردن تعداد خدمات به پاسخ
        data = [
            {
                **category,
                "post_count": category["post_count"]
            }
            for category in serializer.data
        ]

        return Response(data)

class CategoryCreate(APIView): 
    permission_classes = [IsAdmin]
    def post(self, request):
        serializer = CategorySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CommentPublishView(APIView):
    
    def put(self, request, comment_id):
        if((request.user.role == 'seo_expert')or(request.user.role == 'admin')):
            try:
                # دریافت کامنت موردنظر
                comment = Comment.objects.get(id=comment_id)
            except Comment.DoesNotExist:
                return Response({'error': 'Comment not found'}, status=404)

            # تغییر وضعیت به منتشر شده
            comment.is_published = True
            comment.save()

            return Response({'message': 'Comment published successfully.'}, status=200)
        return Response({'detail':"شما به این قسمت دسترسی ندارید"})

class TopViewedPostsView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        # دریافت چهار پست پر بازدید
        top_posts = Post.objects.filter(is_published=True).order_by('-views')[:4]
        serializer = PostSerializer(top_posts, many=True)
        return Response(serializer.data, status=200)


class TopExpertsView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        # دریافت سه کارشناس برتر بر اساس تعداد فالوور
        top_experts = Profile.objects.filter(user__role='expert').annotate(
            post_count=Count('user__posts')  # شمارش تعداد پست‌های ایجاد شده توسط کاربر
        ).order_by('-follower_count')[:3]

        # آماده‌سازی داده‌ها برای پاسخ
        data = []
        for expert in top_experts:
            data.append({
                'username': expert.user.username,
                'bio': expert.bio,
                'avatar': expert.avatar.url if expert.avatar else None,
                'average_rate': expert.average_rate,
                'completed_requests': expert.completed_requests,
                'follower_count': expert.follower_count,
                'post_count': expert.post_count,
            })

        return Response(data, status=status.HTTP_200_OK)