from django.urls import path
from .views import SignUpView, LogoutView, LoginView, SendVerificationCodeView, VerifyPhoneView
from rest_framework_simplejwt.views import TokenRefreshView


urlpatterns = [
    path('register/', SignUpView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('verify-phone/', VerifyPhoneView.as_view(), name='verify-phone'),
    path('send-code/', SendVerificationCodeView.as_view(), name='send_code'),
]
