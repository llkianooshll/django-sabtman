from django.contrib import admin

from .models import PhoneVerification,ActiveSession

admin.site.register(PhoneVerification)
admin.site.register(ActiveSession)
