from django.contrib.auth.models import AbstractUser
from django.db import models
from django.conf import settings


class CustomUser(AbstractUser):
    phone_number = models.CharField(max_length=15, unique=True)
    ROLE_CHOICES = [
        ('user', 'User'),
        ('expert', 'Expert'),
        ('admin', 'Admin'),
        ('accountant', 'Accountant'),  # حسابدار
        ('seo_expert', 'SEO Expert'),  # کارشناس سئو
    ]
    role = models.CharField(max_length=15, choices=ROLE_CHOICES, default='user')
    login_failed_count = models.PositiveIntegerField(default=0)
    is_blocked = models.BooleanField(default=False)
    # daraje bandi karshenas boodan ya user adi boodan
    def can_be_followed(self):
        return self.role == 'expert'

    def can_follow(self):
        return True
class PhoneVerification(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='phone_verification')
    phone_number = models.CharField(max_length=15, unique=True)  # شماره تلفن
    verification_code = models.IntegerField(null=True,blank=True)  # کد تأیید
    is_verified = models.BooleanField(default=False)  # وضعیت تأیید
    created_at = models.DateTimeField(auto_now_add=True)  # تاریخ ایجاد

    def __str__(self):
        return f"{self.user.username} - verified: {self.is_verified}"
    
from django.utils import timezone

class ActiveSession(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sessions')
    user_agent = models.TextField()
    ip_address = models.GenericIPAddressField()
    device_type = models.CharField(max_length=50)
    browser = models.CharField(max_length=100)
    os = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    last_activity = models.DateTimeField(default=timezone.now)
    is_current = models.BooleanField(default=False)  # مثلاً نشست فعلی

    def __str__(self):
        return f"{self.user} - {self.browser} - {self.ip_address}"
