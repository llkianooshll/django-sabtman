from rest_framework.permissions import BasePermission

class IsPhoneVerified(BasePermission):
    """
    اجازه دسترسی فقط به کاربرانی که شماره تلفن آن‌ها تأیید شده است.
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False

        if hasattr(request.user, 'phone_verification') and request.user.phone_verification.is_verified:
            return True

        return False
class IsUser(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['user']
class IsAccountant(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['accountant']
class IsSeoExpert(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['seo_expert']
class IsExpert(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['expert']
class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['admin']
class IsExpertOrAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['expert','admin']

class IsNotBlocked(BasePermission):
    """
    اجازه دسترسی فقط به کاربرانی که بلاک نشده‌اند.
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and not request.user.is_blocked