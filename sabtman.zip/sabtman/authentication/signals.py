from django.db.models.signals import post_save
from django.dispatch import receiver
from django.conf import settings
from .models import PhoneVerification
from django.db import IntegrityError

@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_phone_verification(sender, instance, created, **kwargs):
    if created:
        # بررسی هم user و هم phone_number
        if not PhoneVerification.objects.filter(user=instance).exists() and \
           not PhoneVerification.objects.filter(phone_number=instance.phone_number).exists():
            try:
                PhoneVerification.objects.create(user=instance, phone_number=instance.phone_number)
            except IntegrityError:
                pass  # یا می‌تونی لاگ کنی یا raise
