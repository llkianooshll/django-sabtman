from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.tokens import RefreshToken
from .models import PhoneVerification,ActiveSession,CustomUser
import random
from .serializers import SignUpSerializer,LoginSerializer,PhoneVerificationSerializer
from rest_framework.permissions import AllowAny,IsAuthenticated
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import status
from user_agents import parse
from kavenegar import *
from management.models import SecurityLog,GlobalSecuritySettings
from django.utils import timezone
from datetime import timedelta


def get_global_security_settings():
    return GlobalSecuritySettings.objects.first()

def clean_old_logs():
    now = timezone.now()
    if not hasattr(clean_old_logs, "_last_run") or (now - clean_old_logs._last_run).days >= 7:
        SecurityLog.objects.filter(timestamp__lt=now - timedelta(days=7)).delete()
        clean_old_logs._last_run = now
class SignUpView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        serializer = SignUpSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user_agent_str = request.META.get('HTTP_USER_AGENT', '')
            ip = request.META.get('REMOTE_ADDR', '')
            if GlobalSecuritySettings.track_user_activity:
                SecurityLog.objects.create(
                    user=user,
                    ip_address=ip,
                    user_agent=user_agent_str,
                    event_type="ثبت‌نام موفق",
                    message="کاربر جدید در سیستم ثبت‌نام کرد.",
                    severity="info"
                )
            return Response({'message': 'User created successfully'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework_simplejwt.exceptions import InvalidToken
from rest_framework.exceptions import AuthenticationFailed
class LoginView(TokenObtainPairView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        settings = get_global_security_settings()
        ip = request.META.get('REMOTE_ADDR', '')
        username = request.data.get("username", "ناشناخته")

        # بررسی IP ممنوعه
        if settings and settings.restrict_by_ip:
            not_allowed_ips = [ip.strip() for ip in (settings.not_allowed_ips or "").split(',')]
            if ip in not_allowed_ips:
                return Response({'detail': 'ورود از IP شما مجاز نیست.'}, status=403)

        try:
            # لاگین معمولی
            response = super().post(request, *args, **kwargs)

            # موفقیت
            if response.status_code == 200:
                user = CustomUser.objects.get(username=username)

                # قفل بودن
                if settings and settings.lock_on_failed_attempts and user.login_failed_count >= 5:
                    return Response({'detail': 'اکانت شما قفل شده است.'}, status=403)
                # 2FA
                if settings and settings.two_factor_auth:
                    try:
                        if not user.phone_verification.is_verified:
                            return Response({'detail': 'تأیید شماره تلفن الزامی است.'}, status=403)
                    except ObjectDoesNotExist:
                        return Response({'detail': 'رکورد تأیید شماره یافت نشد.'}, status=403)

                # محدودیت نشست‌ها
                if settings and settings.limit_concurrent_sessions:
                    if user.sessions.count() > 1:
                        return Response({'detail':'محدودیت نشست همزمان اعمال شده است.'}, status=403)

                # ایجاد نشست
                user_agent_str = request.META.get('HTTP_USER_AGENT', '')
                user_agent = parse(user_agent_str)

                if user.role == 'admin' or (settings and settings.track_user_activity):
                    ActiveSession.objects.create(
                        user=user,
                        ip_address=ip,
                        user_agent=user_agent_str,
                        device_type=user_agent.device.family,
                        browser=user_agent.browser.family,
                        os=user_agent.os.family,
                        is_current=True
                    )

                # لاگ ورود موفق
                if settings.track_user_activity:
                    SecurityLog.objects.create(
                        user=user,
                        ip_address=ip,
                        user_agent=user_agent_str,
                        event_type="ورود موفق",
                        message="کاربر وارد سیستم شد.",
                        severity="info"
                    )

                user.login_failed_count = 0
                user.save()

            return response

        except (InvalidToken, AuthenticationFailed):
            # ثبت ورود ناموفق
            user = CustomUser.objects.filter(username=username).first()
            if user:
                user.login_failed_count += 1
                user.save()
            if settings.track_user_activity:
                SecurityLog.objects.create(
                    user=user if user else None,
                    ip_address=ip,
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    event_type="ورود ناموفق",
                    message=f"تلاش ناموفق برای ورود با نام کاربری: {username}",
                    severity="error"
                )
            return Response({'detail': 'نام کاربری یا رمز عبور اشتباه است.'}, status=401)



class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self,request):
        settings = get_global_security_settings()
        try:
            refresh_token = request.data.get('refresh')
            token = RefreshToken(refresh_token)
            token.blacklist()
            clean_old_logs()
            if settings.track_user_activity:
                SecurityLog.objects.create(
                    user=request.user,
                    ip_address=request.META.get('REMOTE_ADDR', ''),
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    event_type="خروج از سیستم",
                    message="کاربر از حساب خود خارج شد.",
                    severity="info"
                )
            user_agent_str = request.META.get('HTTP_USER_AGENT', '')
            user_agent = parse(user_agent_str)
            ip = request.META.get('REMOTE_ADDR', '')
            session = ActiveSession.objects.filter(user=request.user, device_type=user_agent.device.family,ip_address=ip).first()
            if session:
                session.delete()
            return Response({'message':'logout successful'},status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error':'invalid token'},status=status.HTTP_400_BAD_REQUEST)
import random  # اضافه کردن این خط برای تولید کد تصادفی

class SendVerificationCodeView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            phone_verification = request.user.phone_verification
        except ObjectDoesNotExist:
            return Response({'error': 'Phone verification record not found.'}, status=404)
        # تولید کد تأیید 5 رقمی
        phone_verification.verification_code = random.randint(10000, 99999)
        phone_verification.save()
        # ارسال کد تأیید
        api = KavenegarAPI('2F3573756470756468625A795369314B506143756F784D794E53653468317353596C506C5A544730466B513D')
        params = {
            'sender': '2000660110',
            'receptor': '09391631373',
            'message': f'{phone_verification.verification_code}'
        }
        response = api.sms_send(params)
        print(f"Verification code sent to {phone_verification.phone_number}: {phone_verification.verification_code}")

        return Response({'message': 'Verification code sent successfully.'})

class VerifyPhoneView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            phone_verification = request.user.phone_verification
        except ObjectDoesNotExist:
            return Response({'error': 'Phone verification record not found.'}, status=404)
        code = request.query_params.get('verify-code')
        if str(phone_verification.verification_code) == code:
            phone_verification.is_verified = True
            phone_verification.save()
            api = KavenegarAPI('2F3573756470756468625A795369314B506143756F784D794E53653468317353596C506C5A544730466B513D')
            params = {
                'sender': '2000660110',
                'receptor': '09391631373',
                'message': '.عضویت شما با موفقیت تایید شد'
            }
            response = api.sms_send(params)
            return Response({'message': 'Phone number verified successfully.'})
        return Response({'error': 'Invalid verification code.'}, status=400)
