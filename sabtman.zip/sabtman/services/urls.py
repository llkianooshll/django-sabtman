from django.urls import path
from .views import ServiceListView, ServiceDetailView, CategoryListView,LikeServiceView, SellServiceView,CategoryDetailView

urlpatterns = [
    path('', ServiceListView.as_view(), name='service_list'),
    path('<int:pk>/', ServiceDetailView.as_view(), name='service_detail'),
    path('categories/', CategoryListView.as_view(), name='category_list'),
    path('categories/<int:pk>/', CategoryDetailView.as_view(), name='category_detail'),
    path('<int:pk>/like/', LikeServiceView.as_view(), name='service_like'),
    path('<int:pk>/sell/', SellServiceView.as_view(), name='service_sell'),
]