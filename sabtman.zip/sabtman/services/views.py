from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny,IsAuthenticatedOrReadOnly
from .models import Service
from categories.models import Category
from .serializers import ServiceSerializer
from categories.serializers import CategorySerializer
from rest_framework import status
from users.models import Notifications

class ServiceListView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        services = Service.objects.filter(status='active').order_by('-created_at')
        serializer = ServiceSerializer(services, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ServiceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ServiceDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk):
        try:
            service = Service.objects.get(id=pk)
            # افزایش تعداد بازدیدها
            service.views += 1
            service.save()

            serializer = ServiceSerializer(service)
            return Response(serializer.data, status=200)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=404)
class CategoryListView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        categories = Category.objects.all()
        serializer = CategorySerializer(categories, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = CategorySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class CategoryDetailView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = CategorySerializer(category)
        return Response(serializer.data)

    def put(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = CategorySerializer(category, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found'}, status=status.HTTP_404_NOT_FOUND)
        category.delete()
        return Response({'message': 'Category deleted successfully'}, status=status.HTTP_204_NO_CONTENT)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Service

class LikeServiceView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            service = Service.objects.get(id=pk)
            service.likes += 1
            Notifications.objects.create(
                user=service.user,
                title=f'لایک {service.category}',
                message=f"کاربر {request.user.username} سرویس شما را لایک کرد"
            )
            service.save()
            return Response({'message': 'Service liked successfully!', 'likes': service.likes}, status=200)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=404)
class SellServiceView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            service = Service.objects.get(id=pk)
            service.sales += 1
            service.save()
            return Response({'message': 'Service sold successfully!', 'sales': service.sales}, status=200)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=404)

