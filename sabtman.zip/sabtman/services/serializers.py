from rest_framework import serializers
from .models import Service
from categories.serializers import CategorySerializer
from categories.models import Category
from authentication.models import CustomUser

class ServiceSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)  # نمایش اطلاعات کامل دسته‌بندی
    category_id = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all(), source='category', write_only=True)  # برای ایجاد یا ویرایش
    user = serializers.ReadOnlyField(source='user.username')  # فقط خواندنی برای نمایش نام کاربر
    user_id = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all(), source='user', write_only=True)  # برای ایجاد یا ویرایش

    class Meta:
        model = Service
        fields = ['id', 'user', 'user_id', 'description', 'price', 'category', 'category_id', 'status', 'views', 'likes', 'sales', 'created_at', 'updated_at']
        read_only_fields = ['views', 'likes', 'sales', 'created_at', 'updated_at']