from django.urls import path
from .views import ContactUsCreateView,PoshtibaniUsersListView,ConsultationReservationCreateView

urlpatterns = [
    path('send-message/', ContactUsCreateView.as_view(), name='contact-us'),
    path('poshtibani-users/', PoshtibaniUsersListView.as_view(), name='poshtibani-users-list'),
    path('consultation/reserve/', ConsultationReservationCreateView.as_view(), name='consultation-reserve'),
]