from rest_framework import serializers
from .models import ContactUs,ConsultationReservation

class ConsultationReservationSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = ConsultationReservation
        fields = ['id', 'full_name', 'phone', 'date', 'time', 'description', 'category', 'category_name', 'created_at']
        read_only_fields = ['id', 'created_at', 'category_name']
class ContactUsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactUs
        fields = ['id', 'full_name', 'email', 'phone', 'subject', 'message', 'created_at']
        read_only_fields = ['id', 'created_at']