from rest_framework import generics
from .models import ContactUs,ConsultationReservation
from .serializers import ContactUsSerializer,ConsultationReservationSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated,AllowAny
from authentication.models import CustomUser

class ContactUsCreateView(generics.CreateAPIView):
    queryset = ContactUs.objects.all()
    serializer_class = ContactUsSerializer

class PoshtibaniUsersListView(APIView):
    """
    نمایش لیست کاربران با نقش admin به همراه username، first_name و last_name از پروفایل
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        admins = CustomUser.objects.filter(role='admin').select_related('profile')
        results = []
        for admin in admins:
            profile = getattr(admin, 'profile', None)
            avatar_url = ''
            if profile and getattr(profile, 'avatar', None):
                try:
                    avatar_url = profile.avatar.url
                except ValueError:
                    avatar_url = ''
            results.append({
                'username': admin.username,
                'first_name': profile.first_name if profile else '',
                'last_name': profile.last_name if profile else '',
                'avatar': avatar_url,
                'bio': profile.bio if profile else '',
            })
        return Response(results)

class ConsultationReservationCreateView(generics.CreateAPIView):
    queryset = ConsultationReservation.objects.all()
    serializer_class = ConsultationReservationSerializer
    permission_classes = [AllowAny]
