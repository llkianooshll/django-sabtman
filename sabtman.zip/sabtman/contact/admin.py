from django.contrib import admin
from .models import ConsultationReservation,ContactUs

admin.site.register(ContactUs)
admin.site.register(ConsultationReservation)