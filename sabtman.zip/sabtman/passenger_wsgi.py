import sys
import os

# مسیر پروژه
PROJECT_PATH = '/home/cp63789/sarzin-pro/myproject'

# اضافه کردن مسیر پروژه به sys.path
sys.path.insert(0, PROJECT_PATH)

# تنظیم ماژول تنظیمات
os.environ['DJANGO_SETTINGS_MODULE'] = 'kasbokar.settings'

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
