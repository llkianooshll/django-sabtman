from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import UserRequest
from users.models import Profile
from django.db.models import Avg, Count

@receiver(post_save, sender=UserRequest)
def update_expert_average_rate(sender, instance, **kwargs):
    """
    به‌روزرسانی میانگین نمرات کارشناس پس از ثبت فیدبک
    """
    # بررسی اینکه فیدبک ثبت شده و سرویس وجود دارد
    if instance.feedback and instance.service:
        try:
            expert_profile = instance.service.user.profile
            # محاسبه میانگین نمرات فیدبک برای کارشناس
            average_rate = UserRequest.objects.filter(
                service__user=instance.service.user,
                feedback__isnull=False  # فقط درخواست‌هایی که فیدبک دارند
            ).aggregate(Avg('feedback'))['feedback__avg'] or 0.0
            # به‌روزرسانی میانگین نمرات در پروفایل کارشناس
            expert_profile.average_rate = round(average_rate, 2)
            expert_profile.save()
        except Profile.DoesNotExist:
            pass


@receiver(post_save, sender=UserRequest)
def update_completed_requests(sender, instance, **kwargs):
    """
    به‌روزرسانی تعداد درخواست‌های تکمیل‌شده کارشناس
    """
    # بررسی اینکه وضعیت درخواست به 'completed' تغییر کرده است
    if instance.status == 'completed' and instance.service:
        try:
            expert_profile = instance.service.user.profile
            # شمارش تعداد درخواست‌های تکمیل‌شده توسط کارشناس
            completed_count = UserRequest.objects.filter(
                service__user=instance.service.user,
                status='completed'
            ).count()
            # به‌روزرسانی تعداد درخواست‌های تکمیل‌شده در پروفایل کارشناس
            expert_profile.completed_requests = completed_count
            expert_profile.save()
        except Profile.DoesNotExist:
            pass