from django.db import models
from django.conf import settings
from categories.models import Category
from services.models import Service
from transactions.models import Transaction

class UserRequest(models.Model):

    STATUS_CHOICES = [
        ('pending', 'درحال بررسی'),
        ('payment', 'درانتظار پرداخت'),
        ('rejected', 'رد شده'),
        ('completed','تکمیل شده'),
    ]
    transaction = models.OneToOneField(Transaction, on_delete=models.SET_NULL, null=True, blank=True, related_name='user_request')
    service = models.ForeignKey(Service, on_delete=models.SET_NULL,blank=True,null=True ,related_name='user_requests')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='requests')
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='requests')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    feedback = models.PositiveSmallIntegerField(choices=[(i, str(i)) for i in range(1, 6)],blank=True,null=True)

    def __str__(self):
        return f"{self.user.username} - {self.category} - {self.status}"


class Document(models.Model):
    STATUS_CHOICES = [
        ('pending', 'درحال بررسی'),
        ('rejected', 'رد شده'),
        ('confirmed', 'تایید شده'),
    ]
    request = models.ForeignKey(UserRequest, on_delete=models.CASCADE, related_name='documents')
    file = models.FileField(upload_to='documents/')
    title = models.CharField(max_length=200, blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')  # وضعیت مدرک
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Document for {self.request.category} - Status: {self.get_status_display()}"

class RequestMessage(models.Model):
    request = models.ForeignKey(UserRequest, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)  # فرستنده پیام
    message = models.TextField()  # متن پیام
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.sender.username} for Request {self.request.id}"