from rest_framework import serializers
from .models import UserRequest, Document,RequestMessage
from categories.serializers import CategorySerializer
from categories.models import Category
from services.models import Service
from services.serializers import ServiceSerializer

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'file', 'status', 'created_at','title','request']
        read_only_fields = ['created_at','request']

class UserRequestSerializer(serializers.ModelSerializer):
    documents = DocumentSerializer(many=True, read_only=True)
    user = serializers.ReadOnlyField(source='user.username')
    category = CategorySerializer(read_only=True)  # نمایش اطلاعات کامل دسته‌بندی
    category_id = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all(), source='category', write_only=True)
    service = serializers.SerializerMethodField()
    transaction = serializers.SerializerMethodField()  # اضافه کردن فیلد transaction

    class Meta:
        model = UserRequest
        fields = ['id', 'user', 'category', 'category_id', 'status', 'description', 'documents', 'service', 'transaction', 'created_at', 'updated_at']
        read_only_fields = ['status', 'service', 'user', 'created_at']

    def get_service(self, obj):
        if obj.service:
            return {
                "id": obj.service.id,
                "username": obj.service.user.username
            }
        return None

    def get_transaction(self, obj):
        # بررسی وجود تراکنش
        transaction = getattr(obj, 'transaction', None)
        if transaction:
            return {
                "id": transaction.id,
                "amount": transaction.amount,
                "status": transaction.status,
                "created_at": transaction.created_at
            }
        return None

class RequestMessageSerializer(serializers.ModelSerializer):
    sender = serializers.ReadOnlyField(source='sender.username')  # نمایش نام فرستنده

    class Meta:
        model = RequestMessage
        fields = ['id', 'request', 'sender', 'message', 'created_at']
        read_only_fields = ['id', 'request', 'sender', 'created_at']