from django.urls import path
from .views import (
    UserRequestView,
    UserRequestDetailView,
    CancelRequestView,
    DocumentView,
    FileDownloadView,
    FeedbackView,
    RequestMessageView
)

urlpatterns = [
    path('', UserRequestView.as_view(), name='user_requests'),
    path('<int:id>/', UserRequestDetailView.as_view(), name='user_request_detail'),
    path('<int:id>/cancel/', CancelRequestView.as_view(), name='cancel_request'),
    path('<int:id>/files/', DocumentView.as_view(), name='upload_file'),
    path('<int:id>/files/<int:fileId>/', FileDownloadView.as_view(), name='download_file'),
    path('<int:id>/feedback/', FeedbackView.as_view(), name='feedback'),
    path('<int:id>/messages/', RequestMessageView.as_view(), name='request_messages'),
]