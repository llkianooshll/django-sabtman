from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .models import UserRequest, Document,RequestMessage
from .serializers import UserRequestSerializer, DocumentSerializer,RequestMessageSerializer
from django.http import FileResponse
from authentication.permissions import IsPhoneVerified,IsUser,IsNotBlocked
from users.models import Notifications
from django.utils import timezone
from datetime import timedelta
def clean_old_notifications():
    now = timezone.now()
    if not hasattr(clean_old_notifications, "_last_run") or (now - clean_old_notifications._last_run).days >= 1:
        Notifications.objects.filter(created_at__lt=now - timedelta(days=7)).delete()
        clean_old_notifications._last_run = now
class UserRequestView(APIView):
    permission_classes = [IsPhoneVerified,IsNotBlocked]
    clean_old_notifications()
    def get(self, request):
        requests = UserRequest.objects.filter(user=request.user)
        serializer = UserRequestSerializer(requests, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = UserRequestSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user)
            Notifications.objects.create(
                user=request.user,
                title="درخواست ایجاد شد!",
                message="درخواست شما با موفقیت ایجاد شد!"
            )
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class DocumentView(APIView):
    permission_classes = [IsUser,IsPhoneVerified,IsNotBlocked]

    def post(self, request, id):
        try:
            user_request = UserRequest.objects.get(id=id, user=request.user)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=status.HTTP_404_NOT_FOUND)

        serializer = DocumentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(request=user_request)
            Notifications.objects.create(
                user=request.user,
                title='آپلود فایل',
                message='فایل با موفقیت آپلود شد',
            )
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class UserRequestDetailView(APIView):
    permission_classes = [IsUser,IsPhoneVerified,IsNotBlocked]

    def get(self, request, id):
        try:
            user_request = UserRequest.objects.get(id=id, user=request.user)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=status.HTTP_404_NOT_FOUND)

        serializer = UserRequestSerializer(user_request)
        return Response(serializer.data)

    def put(self, request, id):
        try:
            user_request = UserRequest.objects.get(id=id, user=request.user)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=status.HTTP_404_NOT_FOUND)

        if((user_request.status == 'pending')or(user_request.status == 'درحال بررسی')):
            serializer = UserRequestSerializer(user_request, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                Notifications.objects.create(
                    user=request.user,
                    title="بروزرسانی درخواست",
                    message="درخواست شما با موفقیت بروزرسانی شد"
                )
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        return Response({'message':'در خواست شما از حالت (درحال بررسی) خارج شده است. لطفا درخواست دیگری ارسال فرمایید'})

class CancelRequestView(APIView):
    permission_classes = [IsUser,IsPhoneVerified]
    clean_old_notifications()
    def post(self, request, id):
        try:
            user_request = UserRequest.objects.get(id=id, user=request.user)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=status.HTTP_404_NOT_FOUND)

        user_request.status = 'cancelled'
        user_request.save()
        Notifications.objects.create(
            user=request.user,
            title="لغو درخواست",
            message="درخواست شما با موفقیت لغو شد"
        )
        return Response({'message': 'Request cancelled successfully'}, status=status.HTTP_200_OK)


class FileDownloadView(APIView):
    permission_classes = [IsAuthenticated,IsPhoneVerified]

    def get(self, request, id, fileId):
        try:
            document = Document.objects.get(id=fileId, request__id=id, request__user=request.user)
        except Document.DoesNotExist:
            return Response({'error': 'File not found'}, status=status.HTTP_404_NOT_FOUND)
        
        response = FileResponse(document.file.open(), as_attachment=True, filename=document.file.name)
        return response

class FeedbackView(APIView):
    permission_classes = [IsUser,IsPhoneVerified,IsNotBlocked]

    def post(self, request, id):
        try:
            user_request = UserRequest.objects.get(id=id, user=request.user)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=status.HTTP_404_NOT_FOUND)

        feedback = request.data.get('feedback')
        if not feedback:
            return Response({'error': 'Feedback is required'}, status=status.HTTP_400_BAD_REQUEST)

        user_request.feedback = feedback
        Notifications.objects.create(
            user=request.user,
            title="ارسال بازخورد",
            message="بازخورد ارسال شد!"
        )
        user_request.save()
        return Response({'message': 'Feedback submitted successfully'}, status=status.HTTP_200_OK)
class RequestMessageView(APIView):
    permission_classes = [IsPhoneVerified,IsAuthenticated,IsNotBlocked]

    def get(self, request, id):
        try:
            user_request = UserRequest.objects.get(id=id)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=404)

        # دریافت پیام‌های مرتبط با درخواست
        messages = RequestMessage.objects.filter(request=user_request).order_by('created_at')
        serializer = RequestMessageSerializer(messages, many=True)
        return Response(serializer.data)

    def post(self, request, id):
        try:
            user_request = UserRequest.objects.get(id=id)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=404)

        if request.user != user_request.user and request.user.role not in ['admin', 'expert']:
            return Response({'error': 'You do not have permission to send messages for this request.'}, status=403)

        serializer = RequestMessageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(request=user_request, sender=request.user)
            if(request.user != user_request.user):
                Notifications.objects.create(
                    user=user_request.user,
                    title="پیام جدید!",
                    message=f'شما پیام جدید از سوی کاربر {request.user.username} دریافت کردید.'
                )
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)