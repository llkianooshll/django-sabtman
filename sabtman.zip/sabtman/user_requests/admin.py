from django.contrib import admin
from .models import UserRequest

admin.site.register(UserRequest)
