from django.contrib import admin
from django.urls import path
from .views import (RequestsView,UsersProfileView,
                    SpecialistsProfileView,BlockUserView,UnblockUserView,
                    AssignRequestView,StatisticsView,UserRequestsView
                    ,RequestDetailView,CreateTransactionView,UserTransactionHistoryView
                    , DashboardView
                    ,ExpertsTopThree
                    ,RolesDetail
                    ,ServiceDetailView
                    ,ServiceListView
                    ,ServiceStatisticsView
                    ,CategoryDetailView
                    ,CategoryListView
                    ,LatestCommentsView
                    ,AllCommentsView
                    ,ReportsView
                    ,TopExpertsPerformanceView
                    ,ServicePerformanceView
                    ,ContactUsMessages
                    ,ConsultationReservationView
                    ,CreateNotificationView
                    ,ChangeUserRoleView
                    ,AdminApiDocsView
                    ,UsersApiDocsView
                    ,SiteSettingsView
                    ,SecurityLogListView
                    ,ExportSecurityLogsExcelView
                    ,ActiveSessionListView
                    ,RequestsApiDocsView
                    ,SpecialistsApiDocsView
                    ,ServicesApiDocsView
                    ,FilesApiDocsView
                    ,ContactApiDocsView
                    ,BlogApiDocsView
                    ,AuthenticationApiDocsView
                    ,AdminSecuritySettingsView
                    ,ChatRoomApiDocsView
                    )



urlpatterns = [
    path('requests/',RequestsView.as_view(),name='requests'),
    path('users/',UsersProfileView.as_view(),name='users'),
    path('specialists/',SpecialistsProfileView.as_view(),name='specialists'),
    path('users/<int:pk>/block/',BlockUserView.as_view(),name='block_user'),
    path('users/<int:pk>/unblock/',UnblockUserView.as_view(),name='unblock_user'),
    path('categories/', CategoryListView.as_view(), name='category_list'),
    path('categories/<int:pk>/', CategoryDetailView.as_view(), name='category_detail'),
    path('services/', ServiceListView.as_view(), name='service_list'),
    path('services/<int:pk>/', ServiceDetailView.as_view(), name='service_detail'),
    path('requests/<int:pk>/assign/', AssignRequestView.as_view(), name='assign_request'),
    path('statistics/', StatisticsView.as_view(), name='statistics'),
    path('requests/user/<str:username>/', UserRequestsView.as_view(), name='user_requests'),
    path('requests/<int:pk>/', RequestDetailView.as_view(), name='user_request_update'),
    path('transactions/<str:username>/create/', CreateTransactionView.as_view(), name='create_transaction'),
    path('users/<int:user_id>/transactions/', UserTransactionHistoryView.as_view(), name='user_transaction_history'),
    path('dashboard/', DashboardView.as_view(), name='dashboard'),
    path('experts/top-three/',ExpertsTopThree.as_view(),name='top_three'),
    path('roles/',RolesDetail.as_view(),name='roles_detail'),
    path('service-statistics/', ServiceStatisticsView.as_view(), name='service_statistics'),
    path('blog/comments/latest/', LatestCommentsView.as_view(), name='latest_comments'),
    path('blog/comments/', AllCommentsView.as_view(), name='all_comments'),
    path('reports/', ReportsView.as_view(), name='reports'),
    path('experts/performance/', TopExpertsPerformanceView.as_view(), name='top_experts_performance'),
    path('services/performance/', ServicePerformanceView.as_view(), name='service_performance'),
    path('contact/messages/', ContactUsMessages.as_view(), name='contact_us_messages'),
    path('contact/reserves/', ConsultationReservationView.as_view(), name='reserves'),
    path('notifications/create/', CreateNotificationView.as_view(), name='create-notification'),
    path('users/<int:user_id>/change-role/', ChangeUserRoleView.as_view(), name='change-user-role'),
    path('api-docs/', AdminApiDocsView.as_view(), name='admin-api-docs'),
    path('users/api-docs/', UsersApiDocsView.as_view(), name='users-api-docs'),
    path('requests/api-docs/', RequestsApiDocsView.as_view(), name='requests-api-docs'),
    path('specialists/api-docs/', SpecialistsApiDocsView.as_view(), name='specialists-api-docs'),
    path('services/api-docs/', ServicesApiDocsView.as_view(), name='services-api-docs'),
    path('files/api-docs/', FilesApiDocsView.as_view(), name='files-api-docs'),
    path('contact/api-docs/', ContactApiDocsView.as_view(), name='contact-api-docs'),
    path('blog/api-docs/', BlogApiDocsView.as_view(), name='blog-api-docs'),
    path('auth/api-docs/', AuthenticationApiDocsView.as_view(), name='auth-api-docs'),
    path('chatroom/api-docs/', ChatRoomApiDocsView.as_view(), name='chatroom-api-docs'),
    path('site-settings/', SiteSettingsView.as_view(), name='site-settings'),
    path('security-logs/', SecurityLogListView.as_view(), name='security-logs'),
    path('security-logs/export/', ExportSecurityLogsExcelView.as_view(), name='security-logs-export'),
    path('active-sessions/', ActiveSessionListView.as_view(), name='active-sessions'),
    path('security-setting/', AdminSecuritySettingsView.as_view(), name='security-setting'),
]