from authentication.models import CustomUser
from users.models import Profile
from rest_framework import serializers
from user_requests.serializers import DocumentSerializer,ServiceSerializer
from user_requests.models import UserRequest
from .models import SiteSettings,SecurityLog

class SiteSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = SiteSettings
        fields = '__all__'

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id','role','username', 'phone_number', 'is_blocked']
class UserRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id','role','username', 'phone_number', 'is_blocked']
        read_only_fields = ['id','username','phone_number', 'is_blocked']
class UserRequestSerializer(serializers.ModelSerializer):
    documents = DocumentSerializer(many=True, read_only=True)
    user = serializers.ReadOnlyField(source='user.username')
    service = serializers.SerializerMethodField()
    class Meta:
        model = UserRequest
        fields = ['id', 'user', 'category', 'status', 'description', 'documents', 'service','feedback', 'created_at', 'updated_at']
    def get_service(self, obj):
            if obj.service:
                return {
                    "id": obj.service.id,
                    "username": obj.service.user.username
                }
            return None

class ProfileSerializer(serializers.ModelSerializer):
    user = UserProfileSerializer()
    class Meta:
        model = Profile
        fields = ['bio','user', 'avatar', 'email', 'address', 'created_at', 'updated_at','first_name','last_name']

class SecurityLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = SecurityLog
        fields = '__all__'