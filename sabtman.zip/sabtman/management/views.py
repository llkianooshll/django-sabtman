from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import generics,permissions
from authentication.permissions import IsAdmin
from user_requests.models import UserRequest,RequestMessage
from user_requests.serializers import RequestMessageSerializer
from users.models import Profile,Notifications,TransactionHistory,UserAcquisitionSources
from users.serializers import TransactionHistorySerializer
from .serializers import UserRequestSerializer,ProfileSerializer,SiteSettingsSerializer,SecurityLogSerializer
from rest_framework import status
from authentication.models import CustomUser,ActiveSession
from authentication.serializers import ActiveSessionSerializer
from services.serializers import ServiceSerializer,CategorySerializer
from services.models import Service,Category
from django.utils.timezone import now
from django.db.models import Sum,Count,Avg,Q
from blog.models import Comment
from django.utils.dateparse import parse_date
from contact.models import ContactUs,ConsultationReservation
from contact.serializers import ContactUsSerializer,ConsultationReservationSerializer
from .models import SiteSettings,SecurityLog,GlobalSecuritySettings
from django.utils import timezone
from datetime import timedelta
def clean_old_logs():
    now = timezone.now()
    if not hasattr(clean_old_logs, "_last_run") or (now - clean_old_logs._last_run).days >= 7:
        SecurityLog.objects.filter(timestamp__lt=now - timedelta(days=180)).delete()
        clean_old_logs._last_run = now

def clean_old_notifications():
    now = timezone.now()
    if not hasattr(clean_old_notifications, "_last_run") or (now - clean_old_notifications._last_run).days >= 1:
        Notifications.objects.filter(created_at__lt=now - timedelta(days=7)).delete()
        clean_old_notifications._last_run = now

from openpyxl import Workbook

class RequestsView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]
    def get(self, request):
        requests = UserRequest.objects.all().order_by('-created_at')

        if request.query_params.get('export') == 'excel':
            return self.export_to_excel(requests)

        serializer = UserRequestSerializer(requests, many=True)
        return Response(serializer.data)

    def export_to_excel(self, queryset):
        wb = Workbook()
        ws = wb.active
        ws.title = "User Requests"

        # تعریف سرتیترها
        headers = [
            "ID", "User", "Category", "Status", "Description",
            "Service ID", "Service Username", "Feedback",
            "Created At", "Updated At"
        ]
        ws.append(headers)

        for req in queryset:
            ws.append([
                req.id,
                req.user.username,
                req.category.name if req.category else '',
                req.status,
                req.description,
                req.service.id if req.service else '',
                req.service.user.username if req.service else '',
                req.feedback if req.feedback else '',
                req.created_at.strftime('%Y-%m-%d %H:%M'),
                req.updated_at.strftime('%Y-%m-%d %H:%M'),
            ])

        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = 'attachment; filename="user_requests.xlsx"'
        wb.save(response)
        return response


class UserRequestsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request, username):
        try:
            user = CustomUser.objects.get(username=username)
        except CustomUser.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

        # دریافت تمام درخواست‌های کاربر
        requests = UserRequest.objects.filter(user=user).order_by('-created_at')
        serializer = UserRequestSerializer(requests, many=True)
        return Response(serializer.data)

class RequestDetailView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def get(self, request, pk):
        try:
            user_request = UserRequest.objects.get(id=pk)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=404)

        # سریالایز کردن درخواست
        request_serializer = UserRequestSerializer(user_request)

        # دریافت پیام‌های مرتبط با درخواست
        messages = RequestMessage.objects.filter(request=user_request).order_by('created_at')
        message_serializer = RequestMessageSerializer(messages, many=True)

        return Response({
            'request': request_serializer.data,
            'messages': message_serializer.data
        })
    def put(self,request,pk):
        try:
            user_request = UserRequest.objects.get(id=pk)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=404)
        serializer = UserRequestSerializer(user_request,data=request.data,partial=True)
        if serializer.is_valid():
            serializer.save()
            clean_old_notifications()
            Notifications.objects.create(
                user=user_request.user,
                title="بروزرسانی",
                message=f"درخواست شما با آیدی{user_request.id} بروز رسانی شد"
            )
            return Response(serializer.data)

class UsersProfileView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def get(self, request):
        search_query = request.query_params.get('search', '')

        profiles = Profile.objects.filter(user__role='user')

        if search_query:
            profiles = profiles.filter(
                Q(user__username__icontains=search_query) |
                Q(user__first_name__icontains=search_query) |
                Q(user__last_name__icontains=search_query)
            )

        serializer = ProfileSerializer(profiles, many=True)
        return Response(serializer.data)

class SpecialistsProfileView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]
    def get(self,request):
        profiles = Profile.objects.filter(user__role = 'expert')
        serializer = ProfileSerializer(profiles,many=True)
        return Response(serializer.data)
    

class BlockUserView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]  # فقط ادمین‌ها اجازه دسترسی دارند
    def put(self, request, pk):
        try:
            user = CustomUser.objects.get(id=pk)
        except CustomUser.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        clean_old_notifications()
        user.is_blocked = True
        user.save()
        Notifications.objects.create(
            user=user,
            title="Account Blocked",
            message="اکانت شما مسدود شد! لطفا جهت اطلاعات بیشتر با پشتیبانی در ارتباط باشید."
        )
        clean_old_logs()
        if GlobalSecuritySettings.track_user_activity:
            SecurityLog.objects.create(
                user=user,
                ip_address=request.META.get('REMOTE_ADDR', ''),
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                event_type="مسدودسازی کاربر",
                message=f"اکانت کاربر توسط {request.user.email} مسدود شد.",
                severity="error"
            )

        return Response({'message': f'User {user.username} has been blocked successfully.'}, status=status.HTTP_200_OK)
    

class UnblockUserView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]
    def put(self, request, pk):
        try:
            user = CustomUser.objects.get(id=pk)
        except CustomUser.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

        user.is_blocked = False
        user.save()
        clean_old_notifications()
        Notifications.objects.create(
            user=user,
            title="Account Unblocked",
            message="اکانت شما رفع مسدودیت شد! اکنون میتوانید به امکانات وبسایت دسترسی داشته باشید."
        )
        return Response({'message': f'User {user.username} has been unblocked successfully.'}, status=status.HTTP_200_OK)
    
class CategoryListView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def get(self, request):
        # دریافت دسته‌بندی‌ها به همراه تعداد خدمات مرتبط
        categories = Category.objects.annotate(service_count=Count('services'))
        serializer = CategorySerializer(categories, many=True)

        # اضافه کردن تعداد خدمات به پاسخ
        data = [
            {
                **category,
                "service_count": category["service_count"]
            }
            for category in serializer.data
        ]

        return Response(data)

    def post(self, request):
        serializer = CategorySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class CategoryDetailView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = CategorySerializer(category)
        return Response(serializer.data)

    def put(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = CategorySerializer(category, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found'}, status=status.HTTP_404_NOT_FOUND)
        category.delete()
        return Response({'message': 'Category deleted successfully'}, status=status.HTTP_204_NO_CONTENT)

class ServiceListView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        search_query = request.query_params.get('search', '')
        services = Service.objects.filter(status='active')

        if search_query:
            services = services.filter(
                Q(description__icontains=search_query) |
                Q(category__name__icontains=search_query) |
                Q(user__username__icontains=search_query)
            )

        services = services.order_by('-created_at')
        serializer = ServiceSerializer(services, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ServiceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ServiceDetailView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request, pk):
        try:
            service = Service.objects.get(id=pk)
            # افزایش تعداد بازدیدها
            service.views += 1
            service.save()

            serializer = ServiceSerializer(service)
            return Response(serializer.data, status=200)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=404)
class AssignRequestView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def put(self, request, pk):
        try:
            user_request = UserRequest.objects.get(id=pk)
        except UserRequest.DoesNotExist:
            return Response({'error': 'Request not found'}, status=status.HTTP_404_NOT_FOUND)

        service_id = request.data.get('service_id')
        if not service_id:
            return Response({'error': 'service_id is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            service = Service.objects.get(id=service_id)
        except Service.DoesNotExist:
            return Response({'error': 'service not found'}, status=status.HTTP_404_NOT_FOUND)

        # تخصیص درخواست به کارشناس
        user_request.service = service
        user_request.save()
        clean_old_notifications()
        # ایجاد نوتیفیکیشن برای کارشناس
        Notifications.objects.create(
            user=service.user,
            title="درخواست جدید تخصیص داده شد",
            message=f"یک درخواست جدید به شما تخصیص داده شد: {user_request.description}"
        )

        return Response({'message': f'Request {user_request.id} has been assigned to expert {service.user.username}.'}, status=status.HTTP_200_OK)


class StatisticsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')
        export = request.query_params.get('export')

        start_date = parse_date(start_date_str) if start_date_str else None
        end_date = parse_date(end_date_str) if end_date_str else None

        date_filter = Q()
        if start_date and end_date:
            date_filter = Q(created_at__date__gte=start_date) & Q(created_at__date__lte=end_date)
        elif start_date:
            date_filter = Q(created_at__date__gte=start_date)
        elif end_date:
            date_filter = Q(created_at__date__lte=end_date)

        total_users = CustomUser.objects.count()
        blocked_users = CustomUser.objects.filter(is_blocked=True).count()

        total_requests = UserRequest.objects.filter(date_filter).count() if date_filter else UserRequest.objects.count()
        pending_requests = UserRequest.objects.filter(status='pending').filter(date_filter).count() if date_filter else UserRequest.objects.filter(status='pending').count()

        total_services = Service.objects.filter(date_filter).count() if date_filter else Service.objects.count()
        total_notifications = Notifications.objects.filter(date_filter).count() if date_filter else Notifications.objects.count()

        data = {
            "total_users": total_users,
            "blocked_users": blocked_users,
            "total_requests": total_requests,
            "pending_requests": pending_requests,
            "total_services": total_services,
            "total_notifications": total_notifications,
        }

        if export == 'excel':
            return self.export_to_excel(data, start_date, end_date)

        return Response(data, status=200)

    def export_to_excel(self, data, start_date, end_date):
        wb = Workbook()
        ws = wb.active
        ws.title = "Statistics"

        # سربرگ‌ها
        ws.append(["آمار", "مقدار"])

        # اضافه کردن داده‌ها
        for key, value in data.items():
            ws.append([key, value])

        # اضافه کردن بازه تاریخ (اگر داده شده)
        if start_date or end_date:
            ws.append([])
            ws.append(["فیلتر تاریخ"])
            if start_date:
                ws.append(["تاریخ شروع", start_date.strftime('%Y-%m-%d')])
            if end_date:
                ws.append(["تاریخ پایان", end_date.strftime('%Y-%m-%d')])

        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = 'attachment; filename=statistics.xlsx'
        wb.save(response)
        return response



class CreateTransactionView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def post(self, request,username):
        serializer = TransactionHistorySerializer(data=request.data)
        try:
            user = CustomUser.objects.get(username = username)
        except CustomUser.DoesNotExist:
            return Response({'message':'not found'})
        if serializer.is_valid():
            serializer.save(user=user)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

class UserTransactionHistoryView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request, user_id):
        try:
            user = CustomUser.objects.get(id=user_id)
        except CustomUser.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

        transactions = TransactionHistory.objects.filter(user=user).order_by('-created_at')

        # اگر پارامتر export=excel فرستاده شده، فایل اکسل برگردان
        if request.query_params.get('export') == 'excel':
            return self.export_to_excel(transactions, user)

        serializer = TransactionHistorySerializer(transactions, many=True)
        return Response(serializer.data)

    def export_to_excel(self, queryset, user):
        wb = Workbook()
        ws = wb.active
        ws.title = f"Transactions-{user.username}"

        headers = [
            "ID", "Transaction Type", "Amount", "Status",
            "Description", "Created At", "Updated At"
        ]
        ws.append(headers)

        for txn in queryset:
            ws.append([
                txn.id,
                txn.get_transaction_type_display(),
                float(txn.amount),
                txn.get_status_display(),
                txn.description or '',
                txn.created_at.strftime('%Y-%m-%d %H:%M'),
                txn.updated_at.strftime('%Y-%m-%d %H:%M'),
            ])

        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = f'attachment; filename=transaction_history_{user.username}.xlsx'
        wb.save(response)
        return response

    
class DashboardView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def get(self, request):
        # تعداد کل درخواست‌ها
        total_requests = UserRequest.objects.count()

        # درآمد ماهانه (فرض می‌کنیم مدل TransactionHistory دارای فیلد amount است)
        current_month = now().month
        monthly_income = TransactionHistory.objects.filter(
            created_at__month=current_month
        ).aggregate(total_income=Sum('amount'))['total_income'] or 0

        # تعداد کل کاربران
        total_users = CustomUser.objects.count()

        # نرخ تکمیل درخواست‌ها
        completed_requests = UserRequest.objects.filter(status='completed').count()
        completion_rate = (completed_requests / total_requests * 100) if total_requests > 0 else 0

        # ساخت پاسخ
        data = {
            "total_requests": total_requests,
            "monthly_income": monthly_income,
            "total_users": total_users,
            "completion_rate": f"{completion_rate:.2f}%",
        }

        return Response(data, status=200)
class ExpertsTopThree(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]
    def get(self,request):
        top_experts = Profile.objects.filter(user__role='expert').order_by('-average_rate')[:3]
        data = [
            {
                "username": expert.user.username,
                "bio": expert.bio,
                "average_rate": expert.average_rate,
                "completed_requests": expert.completed_requests,
            }
            for expert in top_experts
        ]
        return Response(data, status=200)

class RolesDetail(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]
    def get(self,request):
        expert = CustomUser.objects.filter(role='expert').count()
        user = CustomUser.objects.filter(role='user').count()
        seo_expert = CustomUser.objects.filter(role='seo_expert').count()
        admin = CustomUser.objects.filter(role='admin').count()
        accountant = CustomUser.objects.filter(role='accountant').count()

        data = {
            'admin':{
                'description':'دسترسی کامل به تمام بخش‌های سیستم',
                'role_title':'مدیر سیستم',
                'count':admin
            },
            'expert':{
                'description':'دسترسی به بخش‌های مرتبط با پردازش درخواست‌ها',
                'role_title':'کارشناس',
                'count':expert
            },
            'accountat':{
                'description':'دسترسی به بخش‌های مالی و پرداخت‌ها',
                'role_title':'حسابدار',
                'count':accountant
            },
            'seo_expert':{
                'description':'دسترسی به بخش‌های محتوا و بلاگ',
                'role_title':'کارشناس سئو',
                'count':seo_expert
            },
            'user':{
                'description':'دسترسی محدود به پنل کاربری',
                'role_title':'مشتری',
                'count':user
            },
        }

        return Response(data,status=status.HTTP_200_OK)

class ServiceStatisticsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        # محاسبه کل بازدیدها
        total_views = Service.objects.aggregate(total_views=Sum('views'))['total_views'] or 1

        # پربازدیدترین خدمات
        most_viewed_service = Service.objects.order_by('-views').first()
        most_viewed_data = {
            "name": most_viewed_service.name if most_viewed_service else None,
            "percentage": f"{(most_viewed_service.views / total_views * 100):.2f}%" if most_viewed_service else "0%"
        }

        # محاسبه کل فروش‌ها
        total_sales = Service.objects.aggregate(total_sales=Sum('sales'))['total_sales'] or 1

        # پرفروش‌ترین خدمات
        top_selling_service = Service.objects.order_by('-sales').first()
        top_selling_data = {
            "name": top_selling_service.name if top_selling_service else None,
            "percentage": f"{(top_selling_service.sales / total_sales * 100):.2f}%" if top_selling_service else "0%"
        }

        # محاسبه کل لایک‌ها
        total_likes = Service.objects.aggregate(total_likes=Sum('likes'))['total_likes'] or 1

        # بیشترین رضایت مشتری (بر اساس تعداد لایک‌ها)
        most_liked_service = Service.objects.order_by('-likes').first()
        highest_rated_data = {
            "name": most_liked_service.name if most_liked_service else None,
            "percentage": f"{(most_liked_service.likes / total_likes * 100):.2f}%" if most_liked_service else "0%"
        }

        # ساخت پاسخ
        data = {
            "most_viewed_service": most_viewed_data,
            "top_selling_service": top_selling_data,
            "highest_rated_service": highest_rated_data,
        }

        return Response(data, status=200)

class LatestCommentsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        # دریافت سه کامنت آخر
        latest_comments = Comment.objects.select_related('post').order_by('-created_at')[:3]
        data = [
            {
                "comment_id": comment.id,
                "content": comment.content,
                "created_at": comment.created_at,
                "post_id": comment.post.id,
                "post_title": comment.post.title,
            }
            for comment in latest_comments
        ]
        return Response(data, status=status.HTTP_200_OK)
class AllCommentsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        # دریافت تمامی کامنت‌ها
        all_comments = Comment.objects.select_related('post').order_by('-created_at')
        data = [
            {
                "comment_id": comment.id,
                "content": comment.content,
                "created_at": comment.created_at,
                "post_id": comment.post.id,
                "post_title": comment.post.title,
            }
            for comment in all_comments
        ]
        return Response(data, status=status.HTTP_200_OK)
    


class ReportsView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]  # فقط ادمین‌ها دسترسی دارند

    def get(self, request):
        # دریافت پارامترهای تاریخ از درخواست
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        # تبدیل تاریخ‌ها به فرمت مناسب
        if start_date:
            start_date = parse_date(start_date)
        if end_date:
            end_date = parse_date(end_date)

        # فیلترهای تاریخ
        date_filter_user = Q()
        date_filter_request = Q()
        date_filter_transaction = Q()

        if start_date:
            date_filter_user &= Q(created_at__gte=start_date)  # برای کاربران از date_joined استفاده می‌کنیم
            date_filter_request &= Q(created_at__gte=start_date)
            date_filter_transaction &= Q(created_at__gte=start_date)
        if end_date:
            date_filter_user &= Q(created_at__lte=end_date)
            date_filter_request &= Q(created_at__lte=end_date)
            date_filter_transaction &= Q(created_at__lte=end_date)

        # درخواست‌های تکمیل‌شده
        completed_requests_count = UserRequest.objects.filter(date_filter_request & Q(status='completed')).count()

        # تعداد کاربران جدید
        new_users_count = CustomUser.objects.filter(date_filter_user).count()

        # درآمد کل
        total_income = TransactionHistory.objects.filter(date_filter_transaction).aggregate(total=Sum('amount'))['total'] or 0

        # میانگین رضایت
        average_feedback = UserRequest.objects.filter(date_filter_request & Q(feedback__isnull=False)).aggregate(avg_feedback=Avg('feedback'))['avg_feedback'] or 0

        # ساخت پاسخ
        data = {
            "completed_requests_count": completed_requests_count,
            "new_users_count": new_users_count,
            "total_income": total_income,
            "average_feedback": round(average_feedback, 2),  # گرد کردن میانگین رضایت به دو رقم اعشار
        }

        return Response(data, status=200)
class UserAcquisitionSourcesView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        # دریافت آخرین رکورد منابع جذب کاربران
        sources = UserAcquisitionSources.objects.last()
        if not sources:
            return Response({'error': 'No data available.'}, status=status.HTTP_404_NOT_FOUND)

        data = {
            "google_ads": sources.google_ads,
            "organic_search": sources.organic_search,
            "social_media": sources.social_media,
            "referrals": sources.referrals,
            "others": sources.others,
        }
        return Response(data, status=status.HTTP_200_OK)

class TopExpertsPerformanceView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]  # فقط ادمین‌ها دسترسی دارند

    def get(self, request):
        # دریافت کارشناسان و مرتب‌سازی بر اساس تعداد درخواست‌های تکمیل‌شده و میانگین بازخورد
        top_experts = Profile.objects.filter(user__role='expert').annotate(
            total_feedback=Avg('user__requests__feedback'),
            total_completed_requests=Count('user__requests', filter=Q(user__requests__status='completed'))
        ).order_by('-total_completed_requests', '-total_feedback')[:4]

        # ساخت داده‌های پاسخ
        data = [
            {
                "username": expert.user.username,
                "total_completed_requests": expert.total_completed_requests,
                "average_feedback": round(expert.total_feedback, 2) if expert.total_feedback else 0,
                "bio": expert.bio,
            }
            for expert in top_experts
        ]

        return Response(data, status=status.HTTP_200_OK)
    
class ServicePerformanceView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]  # فقط ادمین‌ها دسترسی دارند

    def get(self, request):
        # دریافت دسته‌بندی‌ها و محاسبه اطلاعات مرتبط
        categories = Category.objects.all()
        data = []

        for category in categories:
            # تعداد کل درخواست‌ها در هر دسته‌بندی
            total_requests = UserRequest.objects.filter(category=category).count()

            # محاسبه میانگین رضایت مشتری
            feedbacks = UserRequest.objects.filter(category=category, feedback__isnull=False).values_list('feedback', flat=True)
            average_feedback = sum(feedbacks) / len(feedbacks) if feedbacks else None

            # محاسبه میانگین زمان تکمیل درخواست‌ها
            completed_requests = UserRequest.objects.filter(category=category, status='completed')
            total_completion_time = sum((request.updated_at - request.created_at).days for request in completed_requests)
            average_completion_time = total_completion_time / len(completed_requests) if completed_requests else None

            # ساخت داده‌های پاسخ
            data.append({
                "category_name": category.name,
                "total_requests": total_requests,
                "average_feedback": round(average_feedback, 2) if average_feedback is not None else "نامشخص",
                "average_completion_time": round(average_completion_time, 2) if average_completion_time is not None else "نامشخص",
            })

        return Response(data, status=status.HTTP_200_OK)
    

class ContactUsMessages(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def get(self, request):
        messages = ContactUs.objects.all().order_by('-created_at')
        serializer = ContactUsSerializer(messages, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
class ConsultationReservationView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def get(self, request):
        reserves = ConsultationReservation.objects.all().order_by('-created_at')
        serializer = ConsultationReservationSerializer(reserves, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class CreateNotificationView(APIView):
    """
    ادمین می‌تواند برای یک کاربر خاص یا همه کاربران نوتیفیکیشن ارسال کند.
    اگر user_id ارسال شود فقط برای همان کاربر، اگر ارسال نشود برای همه کاربران ارسال می‌شود.
    """
    permission_classes = [IsAuthenticated,IsAdmin]

    def post(self, request):
        title = request.data.get('title')
        message = request.data.get('message')
        user_id = request.data.get('user_id')  # اختیاری

        if not title or not message:
            return Response({'detail': 'title و message الزامی هستند.'}, status=status.HTTP_400_BAD_REQUEST)

        if user_id:
            try:
                user = CustomUser.objects.get(id=user_id)
            except CustomUser.DoesNotExist:
                return Response({'detail': 'کاربر مورد نظر پیدا نشد.'}, status=status.HTTP_404_NOT_FOUND)
            Notifications.objects.create(user=user, title=title, message=message)
            return Response({'detail': f'نوتیفیکیشن برای کاربر {user.username} ارسال شد.'}, status=status.HTTP_201_CREATED)
        else:
            users = CustomUser.objects.all()
            notifications = [
                Notifications(user=user, title=title, message=message)
                for user in users
            ]
            Notifications.objects.bulk_create(notifications)
            return Response({'detail': 'نوتیفیکیشن برای همه کاربران ارسال شد.'}, status=status.HTTP_201_CREATED)
        
class ChangeUserRoleView(APIView):
    """
    ادمین می‌تواند نقش هر کاربر را تغییر دهد.
    """
    permission_classes = [IsAuthenticated,IsAdmin]

    def put(self, request, user_id):
        clean_old_logs()
        new_role = request.data.get('role')
        if not new_role:
            return Response({'detail': 'فیلد role الزامی است.'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user = CustomUser.objects.get(id=user_id)
        except CustomUser.DoesNotExist:
            return Response({'detail': 'کاربر مورد نظر پیدا نشد.'}, status=status.HTTP_404_NOT_FOUND)

        user.role = new_role
        user.save()
        clean_old_notifications()
        Notifications.objects.create(
            user=user,
            title="تغییر نقش",
            message=f"نقش شما توسط ادمین به {new_role} تغییر یافت."
        )
        if GlobalSecuritySettings.track_user_activity:
            SecurityLog.objects.create(
                user=user,
                ip_address=request.META.get('REMOTE_ADDR', ''),
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                event_type="تغییر سطح دسترسی",
                message=f"نقش کاربر به {new_role} تغییر یافت توسط {request.user.email}",
                severity="warning"
            )
        return Response({'detail': f'نقش کاربر {user.username} با موفقیت به {new_role} تغییر یافت.'}, status=status.HTTP_200_OK)
class AdminApiDocsView(APIView):
    """
    نمایش مستندات دقیق همه APIهای ادمین با نقش دسترسی
    """
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {"endpoint": "/api/admin/requests/", "method": "GET", "description": "لیست همه درخواست‌ها", "role": "admin"},
            {"endpoint": "/api/admin/requests/?export=excel", "method": "GET", "description": "لیست همه درخواست‌ها به صورت فایل اکسل", "role": "admin"},
            {"endpoint": "/api/admin/users/", "method": "GET", "description": "لیست پروفایل کاربران", "role": "admin"},
            {"endpoint": "/api/admin/specialists/", "method": "GET", "description": "لیست پروفایل کارشناسان", "role": "admin"},
            {"endpoint": "/api/admin/users/<int:pk>/block/", "method": "PUT", "description": "بلاک کردن کاربر", "role": "admin"},
            {"endpoint": "/api/admin/users/<int:pk>/unblock/", "method": "PUT", "description": "آنبلاک کردن کاربر", "role": "admin"},
            {"endpoint": "/api/admin/categories/", "method": "GET, POST", "description": "لیست و ایجاد دسته‌بندی", "role": "admin"},
            {"endpoint": "/api/admin/categories/<int:pk>/", "method": "GET, PUT, DELETE", "description": "جزییات، ویرایش و حذف دسته‌بندی", "role": "admin"},
            {"endpoint": "/api/admin/services/", "method": "GET, POST", "description": "لیست و ایجاد خدمات", "role": "admin"},
            {"endpoint": "/api/admin/services/<int:pk>/", "method": "GET, PUT, DELETE", "description": "جزییات، ویرایش و حذف خدمت", "role": "admin"},
            {"endpoint": "/api/admin/requests/<int:pk>/assign/", "method": "PUT", "description": "تخصیص درخواست به کارشناس", "role": "admin"},
            {"endpoint": "/api/admin/statistics/", "method": "GET", "description": "آمار کلی", "role": "admin"},
            {"endpoint": "/api/admin/statistics/?start-date=1&end-date=2", "method": "GET", "description": " آمار کلی با فیلتر بازه ای تاریخ", "role": "admin"},
            {"endpoint": "/api/admin/statistics/?export=excel", "method": "GET", "description": " آمار کلی به صورت اکسل", "role": "admin"},
            {"endpoint": "/api/admin/requests/user/<str:username>/", "method": "GET", "description": "درخواست‌های یک کاربر خاص", "role": "admin"},
            {"endpoint": "/api/admin/requests/<int:pk>/", "method": "GET, PUT", "description": "جزییات و ویرایش یک درخواست", "role": "admin"},
            {"endpoint": "/api/admin/transactions/<str:username>/create/", "method": "POST", "description": "ایجاد تراکنش برای کاربر", "role": "admin"},
            {"endpoint": "/api/admin/users/<int:user_id>/transactions/", "method": "GET", "description": "لیست تراکنش‌های کاربر", "role": "admin"},
            {"endpoint": "/api/admin/users/<int:user_id>/transactions/?export=excel", "method": "GET", "description": "لیست تراکنش‌های کاربر به صورت اکسل", "role": "admin"},
            {"endpoint": "/api/admin/dashboard/", "method": "GET", "description": "آمار داشبورد", "role": "admin"},
            {"endpoint": "/api/admin/experts/top-three/", "method": "GET", "description": "سه کارشناس برتر", "role": "admin"},
            {"endpoint": "/api/admin/roles/", "method": "GET", "description": "آمار نقش‌ها", "role": "admin"},
            {"endpoint": "/api/admin/service-statistics/", "method": "GET", "description": "آمار خدمات", "role": "admin"},
            {"endpoint": "/api/admin/blog/comments/latest/", "method": "GET", "description": "سه کامنت آخر", "role": "admin"},
            {"endpoint": "/api/admin/blog/comments/", "method": "GET", "description": "همه کامنت‌ها", "role": "admin"},
            {"endpoint": "/api/admin/reports/", "method": "GET", "description": "گزارش‌های آماری", "role": "admin"},
            {"endpoint": "/api/admin/experts/performance/", "method": "GET", "description": "عملکرد برترین کارشناسان", "role": "admin"},
            {"endpoint": "/api/admin/services/performance/", "method": "GET", "description": "عملکرد خدمات بر اساس دسته‌بندی", "role": "admin"},
            {"endpoint": "/api/admin/contact/messages/", "method": "GET", "description": "لیست پیام‌های ارتباط با ما", "role": "admin"},
            {"endpoint": "/api/admin/contact/reserves/", "method": "GET", "description": "لیست رزروهای مشاوره", "role": "admin"},
            {"endpoint": "/api/admin/notifications/create/", "method": "POST", "description": "ارسال نوتیفیکیشن به یک کاربر یا همه", "role": "admin"},
            {"endpoint": "/api/admin/users/<int:user_id>/change-role/", "method": "PUT", "description": "تغییر نقش کاربر", "role": "admin"},
            {"endpoint": "/api/admin/api-docs/", "method": "GET", "description": "مستندات API ادمین", "role": "admin"},
            {"endpoint": "/api/admin/users/api-docs/", "method": "GET", "description": "مستندات API کاربران", "role": "admin"},
        ]
        return Response(docs, status=status.HTTP_200_OK)


class UsersApiDocsView(APIView):
    """
    نمایش مستندات ساده APIهای اپلیکیشن users
    فقط برای ادمین
    """
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {"endpoint": "/api/users/profile/", "method": "GET, PUT", "description": "دریافت و ویرایش پروفایل کاربر"},
            {"endpoint": "/api/users/notifications/", "method": "GET", "description": "لیست نوتیفیکیشن‌های کاربر"},
            {"endpoint": "/api/users/notifications/<pk>/", "method": "GET, PUT", "description": "جزییات و خواندن نوتیفیکیشن"},
            {"endpoint": "/api/users/change-password/", "method": "PUT", "description": "تغییر رمز عبور کاربر"},
            {"endpoint": "/api/users/transactions/", "method": "GET", "description": "لیست تراکنش‌های کاربر"},
            {"endpoint": "/api/users/chat-rooms/", "method": "GET, POST", "description": "لیست و ایجاد روم چت"},
            {"endpoint": "/api/users/chat-messages/<room_name>/", "method": "GET", "description": "لیست پیام‌های یک روم چت"},
            {"endpoint": "/api/users/acquisition-sources/", "method": "PUT", "description": "به‌روزرسانی منابع جذب کاربر"},
            {"endpoint": "/api/users/follow/<user_id>/", "method": "POST, DELETE", "description": "فالو و آنفالو کردن کاربر"},
            {"endpoint": "/api/users/follow-list/", "method": "GET", "description": "لیست فالوینگ‌ها و فالوورها"},
            {"endpoint": "/api/users/dashboard/", "method": "GET", "description": "داشبورد کاربر (درخواست‌ها و تیکت‌ها)"},
        ]
        return Response(docs)
class RequestsApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/user-requests/",
                "method": "GET",
                "description": "لیست درخواست‌های کاربر فعلی"
            },
            {
                "path": "/api/user-requests/",
                "method": "POST",
                "description": "ایجاد درخواست جدید"
            },
            {
                "path": "/api/user-requests/<id>/",
                "method": "GET",
                "description": "دریافت جزئیات یک درخواست"
            },
            {
                "path": "/api/user-requests/<id>/",
                "method": "PUT",
                "description": "ویرایش درخواست در حال بررسی"
            },
            {
                "path": "/api/user-requests/<id>/cancel/",
                "method": "POST",
                "description": "لغو درخواست"
            },
            {
                "path": "/api/user-requests/<id>/files/",
                "method": "POST",
                "description": "آپلود فایل برای درخواست"
            },
            {
                "path": "/api/user-requests/<id>/files/<fileId>/",
                "method": "GET",
                "description": "دانلود فایل درخواست"
            },
            {
                "path": "/api/user-requests/<id>/feedback/",
                "method": "POST",
                "description": "ارسال بازخورد برای درخواست"
            },
            {
                "path": "/api/user-requests/<id>/messages/",
                "method": "GET",
                "description": "دریافت پیام‌های درخواست"
            },
            {
                "path": "/api/user-requests/<id>/messages/",
                "method": "POST",
                "description": "ارسال پیام در یک درخواست"
            }
        ]

        return Response(docs)
class SpecialistsApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/specialist/dashboard/",
                "method": "GET",
                "description": "نمایش داشبورد کارشناس با آمار کلی، درخواست‌ها، تیکت‌ها و عملکرد"
            },
            {
                "path": "/api/specialist/todolist/",
                "method": "GET",
                "description": "لیست تسک‌های ۲۴ ساعت اخیر کارشناس"
            },
            {
                "path": "/api/specialist/todolist/",
                "method": "POST",
                "description": "ایجاد آیتم جدید در تسک‌لیست"
            },
            {
                "path": "/api/specialist/todolist/<int:pk>/",
                "method": "DELETE",
                "description": "حذف آیتم از تسک‌لیست"
            },
            {
                "path": "/api/specialist/requests/",
                "method": "GET",
                "description": "لیست درخواست‌های مربوط به کارشناس با صفحه‌بندی"
            },
            {
                "path": "/api/specialist/requests/<int:pk>/",
                "method": "GET",
                "description": "جزئیات یک درخواست به همراه پیام‌ها"
            },
            {
                "path": "/api/specialist/tickets/",
                "method": "GET",
                "description": "لیست تیکت‌هایی که کارشناس یکی از طرفین آن‌هاست"
            },
            {
                "path": "/api/specialist/tickets/<int:pk>/",
                "method": "GET",
                "description": "نمایش جزئیات تیکت به همراه پیام‌ها در صورتی که کارشناس یکی از طرفین باشد"
            },
            {
                "path": "/api/specialist/documents/",
                "method": "GET",
                "description": "لیست مدارک مربوط به درخواست‌های کارشناس"
            },
            {
                "path": "/api/specialist/documents/<int:pk>/approve/",
                "method": "POST",
                "description": "تایید یک مدرک توسط کارشناس"
            },
            {
                "path": "/api/specialist/documents/<int:pk>/reject/",
                "method": "POST",
                "description": "رد یک مدرک توسط کارشناس"
            },
            {
                "path": "/api/specialist/documents/checked/",
                "method": "GET",
                "description": "لیست مدارک تایید یا رد شده توسط کارشناس"
            }
        ]

        return Response(docs)
class TicketsApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/tickets/",
                "method": "GET",
                "description": "دریافت لیست تیکت‌های کاربر"
            },
            {
                "path": "/api/tickets/",
                "method": "POST",
                "description": "ایجاد تیکت جدید"
            },
            {
                "path": "/api/tickets/<int:ticket_id>/messages/",
                "method": "GET",
                "description": "دریافت پیام‌های مربوط به یک تیکت خاص"
            },
            {
                "path": "/api/tickets/<int:ticket_id>/messages/",
                "method": "POST",
                "description": "ارسال پیام جدید برای یک تیکت"
            }
        ]
        return Response(docs)
class ServicesApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/services/",
                "method": "GET",
                "description": "دریافت لیست سرویس‌های فعال"
            },
            {
                "path": "/api/services/",
                "method": "POST",
                "description": "ایجاد سرویس جدید"
            },
            {
                "path": "/api/services/<int:pk>/",
                "method": "GET",
                "description": "دریافت جزئیات یک سرویس خاص و افزایش بازدید"
            },
            {
                "path": "/api/services/categories/",
                "method": "GET",
                "description": "دریافت لیست دسته‌بندی‌ها"
            },
            {
                "path": "/api/services/categories/",
                "method": "POST",
                "description": "ایجاد دسته‌بندی جدید"
            },
            {
                "path": "/api/services/categories/<int:pk>/",
                "method": "GET",
                "description": "دریافت جزئیات یک دسته‌بندی"
            },
            {
                "path": "/api/services/categories/<int:pk>/",
                "method": "PUT",
                "description": "ویرایش دسته‌بندی"
            },
            {
                "path": "/api/services/categories/<int:pk>/",
                "method": "DELETE",
                "description": "حذف دسته‌بندی"
            },
            {
                "path": "/api/services/<int:pk>/like/",
                "method": "POST",
                "description": "لایک کردن سرویس"
            },
            {
                "path": "/api/services/<int:pk>/sell/",
                "method": "POST",
                "description": "افزایش تعداد فروش سرویس"
            }
        ]
        return Response(docs)
class FilesApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/files/upload/",
                "method": "POST",
                "description": "آپلود فایل جدید (فقط برای کاربران احراز هویت شده و دارای شماره تاییدشده)"
            },
            {
                "path": "/api/files/<int:id>/download/",
                "method": "GET",
                "description": "دانلود فایل براساس شناسه (فقط برای کاربران احراز هویت شده)"
            }
        ]

        return Response(docs)
class ContactApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/contact/send-message/",
                "method": "POST",
                "description": "ارسال پیام از طریق فرم تماس با ما"
            },
            {
                "path": "/api/contact/poshtibani-users/",
                "method": "GET",
                "description": "دریافت لیست کاربران با نقش ادمین به همراه اطلاعات پروفایل (فقط برای کاربران احراز هویت شده)"
            },
            {
                "path": "/api/contact/consultation/reserve/",
                "method": "POST",
                "description": "ثبت رزرو مشاوره (در دسترس برای همه کاربران)"
            }
        ]
        return Response(docs)
class CategoriesApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/category/create/",
                "method": "POST",
                "description": "ایجاد دسته‌بندی جدید (فقط برای admin)"
            }
        ]
        return Response(docs)
class BlogApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/api/posts/",
                "method": "GET",
                "description": "دریافت لیست پست‌ها (پست‌های منتشر شده برای کاربران عادی و همه پست‌ها برای ادمین و سئو اکسپرت)"
            },
            {
                "path": "/api/posts/",
                "method": "POST",
                "description": "ایجاد پست جدید (فقط توسط ادمین)"
            },
            {
                "path": "/api/posts/<post_id>/",
                "method": "GET",
                "description": "نمایش جزئیات پست به همراه نظرات (برای کاربران معمولی فقط نظرات منتشر شده)"
            },
            {
                "path": "/api/posts/<post_id>/update-delete/",
                "method": "PUT",
                "description": "ویرایش پست (فقط توسط ادمین)"
            },
            {
                "path": "/api/posts/<post_id>/update-delete/",
                "method": "DELETE",
                "description": "حذف پست (فقط توسط ادمین)"
            },
            {
                "path": "/api/comments/<comment_id>/delete/",
                "method": "DELETE",
                "description": "حذف نظر (فقط توسط ادمین)"
            },
            {
                "path": "/api/posts/<post_id>/comment/",
                "method": "POST",
                "description": "ثبت نظر برای یک پست (در صورت منتشر بودن پست)"
            },
            {
                "path": "/api/categories/",
                "method": "GET",
                "description": "لیست دسته‌بندی‌ها همراه با تعداد پست‌ها"
            },
            {
                "path": "/api/categories/create/",
                "method": "POST",
                "description": "ایجاد دسته‌بندی (فقط توسط ادمین)"
            },
            {
                "path": "/api/comments/<comment_id>/publish/",
                "method": "PUT",
                "description": "تأیید و انتشار یک نظر (فقط توسط ادمین)"
            },
            {
                "path": "/api/posts/top/",
                "method": "GET",
                "description": "دریافت ۴ پست پر بازدید منتشر شده"
            },
            {
                "path": "/api/top-experts/",
                "method": "GET",
                "description": "دریافت ۳ کارشناس برتر بر اساس تعداد فالوور و پست"
            }
        ]
        return Response(docs)
class AuthenticationApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "endpoint": "/register/",
                "method": "POST",
                "description": "ثبت‌نام کاربر جدید. دریافت داده‌های کاربر و ایجاد حساب کاربری جدید در سیستم."
            },
            {
                "endpoint": "/login/",
                "method": "POST",
                "description": "ورود کاربر با نام کاربری و رمز عبور. در صورت موفقیت، توکن JWT صادر می‌شود و لاگ امنیتی ایجاد می‌شود."
            },
            {
                "endpoint": "/logout/",
                "method": "POST",
                "description": "خروج کاربر از سیستم با بلاک کردن توکن رفرش ارسالی و ثبت لاگ خروج."
            },
            {
                "endpoint": "/refresh/",
                "method": "POST",
                "description": "تجدید توکن JWT با ارسال توکن رفرش."
            },
            {
                "endpoint": "/verify-phone/",
                "method": "POST",
                "description": "تایید شماره تلفن کاربر با بررسی کد ارسال شده به گوشی و فعال‌سازی وضعیت تایید شماره."
            },
            {
                "endpoint": "/send-code/",
                "method": "POST",
                "description": "ارسال کد تأیید پنج رقمی به شماره تلفن کاربر جهت فرایند تایید شماره."
            }
        ]
        return Response(docs)
class ChatRoomApiDocsView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        docs = [
            {
                "path": "/chat/",
                "method": "POST",
                "description": "ایجاد چت بین کاربر و کارشناس (فقط توسط کاربران با نقش user)"
            },
            {
                "path": "/chat/",
                "method": "GET",
                "description": "دریافت لیست چت‌های مربوط به کاربر یا کارشناس"
            },
            {
                "path": "/chat/<chat_id>/messages/",
                "method": "GET",
                "description": "دریافت لیست پیام‌ها در یک چت مشخص"
            },
            {
                "path": "/chat/<chat_id>/messages/",
                "method": "POST",
                "description": "ارسال پیام جدید در یک چت مشخص"
            }
        ]

        return Response(docs)

class SiteSettingsView(generics.RetrieveUpdateAPIView):
    queryset = SiteSettings.objects.all()
    serializer_class = SiteSettingsSerializer
    permission_classes = [IsAdmin]

    def get_object(self):
        # فقط یک رکورد باید وجود داشته باشد
        return SiteSettings.objects.first()


class ActiveSessionListView(generics.ListAPIView):
    serializer_class = ActiveSessionSerializer
    permission_classes = [IsAuthenticated,IsAdmin]

    def get_queryset(self):
        return ActiveSession.objects.filter(user=self.request.user)

class ActiveSessionLogoutView(APIView):
    permission_classes = [IsAdmin]

    def post(self, request, session_id):
        try:
            session = ActiveSession.objects.get(id=session_id, user=request.user)
            session.delete()
            return Response({'message': 'خروج از نشست موفق بود.'})
        except ActiveSession.DoesNotExist:
            return Response({'error': 'نشست پیدا نشد.'}, status=404)


class SecurityLogListView(generics.ListAPIView):
    serializer_class = SecurityLogSerializer
    permission_classes = [IsAuthenticated,IsAdmin]  # یا RolePermission

    def get_queryset(self):
        return SecurityLog.objects.all().order_by('-timestamp')

import pandas as pd
from django.http import HttpResponse

class ExportSecurityLogsExcelView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        logs = SecurityLog.objects.all().select_related("user").order_by("-timestamp")
        data = [{
            "کاربر": log.user.username if log.user else "سیستم",
            "IP": log.ip_address,
            "مرورگر": log.user_agent[:100],
            "نوع رخداد": log.event_type,
            "پیام": log.message,
            "شدت": log.severity,
            "زمان": log.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        } for log in logs]

        df = pd.DataFrame(data)
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=security_logs.xlsx'
        df.to_excel(response, index=False, engine='openpyxl')
        return response
    

class ActiveSessionListView(APIView):
    permission_classes = [IsAuthenticated, IsAdmin]

    def get(self, request):
        sessions = ActiveSession.objects.select_related('user').all().order_by('-created_at')
        data = [{
            "username": session.user.username,
            "ip": session.ip_address,
            "browser": session.browser,
            "os": session.os,
            "device": session.device_type,
            "user_agent": session.user_agent,
            "created": session.created_at
        } for session in sessions]
        return Response(data)


# views.py
class AdminSecuritySettingsView(APIView):
    permission_classes = [IsAuthenticated,IsAdmin]

    def get(self, request):
        settings = GlobalSecuritySettings.objects.first()
        if not settings:
            return Response({'error': 'Settings not found.'}, status=404)
        return Response({
            'two_factor_auth': settings.two_factor_auth,
            'lock_on_failed_attempts': settings.lock_on_failed_attempts,
            'limit_concurrent_sessions': settings.limit_concurrent_sessions,
            'track_user_activity': settings.track_user_activity,
            'restrict_by_ip': settings.restrict_by_ip,
            'not_allowed_ips': settings.not_allowed_ips,
        })

    def post(self, request):
        settings, created = GlobalSecuritySettings.objects.get_or_create(id=1)
        for field in ['two_factor_auth', 'lock_on_failed_attempts', 'limit_concurrent_sessions',
                      'track_user_activity', 'restrict_by_ip', 'not_allowed_ips']:
            if field in request.data:
                setattr(settings, field, request.data[field])
        settings.save()
        return Response({'message': 'Settings updated successfully.'})
