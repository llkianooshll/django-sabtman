from django.contrib import admin
from authentication.models import CustomUser
from .models import SecurityLog,GlobalSecuritySettings
admin.site.register(SecurityLog)
admin.site.register(GlobalSecuritySettings)
@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ['username', 'email', 'role', 'is_blocked']
    list_filter = ['role', 'is_blocked']
    search_fields = ['username', 'email', 'phone_number']

