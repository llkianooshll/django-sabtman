# models.py
from django.db import models
from django.conf import settings

class SiteSettings(models.Model):
    site_name = models.CharField("نام سایت", max_length=255)
    site_description = models.TextField("توضیحات سایت")
    contact_email = models.EmailField("ایمیل تماس")
    contact_phone = models.CharField("شماره تماس", max_length=20)
    address = models.TextField("آدرس")
    logo = models.ImageField("لوگو", upload_to='site-setting/', blank=True, null=True)
    favicon = models.ImageField("فاویکون", upload_to='site-setting/', blank=True, null=True)

    class Meta:
        verbose_name = "تنظیمات سایت"
        verbose_name_plural = "تنظیمات سایت"

    def __str__(self):
        return "تنظیمات سایت"
# models.py
class SecurityLog(models.Model):
    SEVERITY_CHOICES = [
        ('info', 'اطلاعات'),
        ('warning', 'هشدار'),
        ('error', 'خطا'),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True)
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField()
    event_type = models.CharField(max_length=100)
    message = models.TextField()
    severity = models.CharField(max_length=10, choices=SEVERITY_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"[{self.severity}] {self.event_type} - {self.user}"
    
# models.py
class GlobalSecuritySettings(models.Model):
    two_factor_auth = models.BooleanField(default=False)
    lock_on_failed_attempts = models.BooleanField(default=False)
    limit_concurrent_sessions = models.BooleanField(default=False)
    track_user_activity = models.BooleanField(default=False)
    restrict_by_ip = models.BooleanField(default=False)
    not_allowed_ips = models.TextField(blank=True, null=True)  # لیست IPها با ویرگول جدا شده

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "Global Security Settings"

