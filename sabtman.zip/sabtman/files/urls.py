from django.urls import path
from .views import FileUploadView, FileDownloadView

urlpatterns = [
    path('upload/', FileUploadView.as_view(), name='file_upload'),
    path('<int:id>/download/', FileDownloadView.as_view(), name='file_download'),
]