from rest_framework import generics
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from .serializers import UserSerializer
from rest_framework.authtoken.models import Token
from .models import User


class LogoutAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        request.user.auth_token.delete()
        return Response(
            data={'message': f'Bye {request.user.username}!'},
            status=status.HTTP_204_NO_CONTENT
        )

class UserRegistration(generics.CreateAPIView):
    serializer_class = UserSerializer

class UserLogin(APIView):
    results = User.objects.all()
    for result in results:
        print(result)
    def post(self,request):
       username = request.data.get('username')
       password =request.data.get('password') 

       user = authenticate(username = username,password=password)
       if user:
           token, created = Token.objects.get_or_create(user=user)
           return Response({'token': token.key}, status=status.HTTP_200_OK)



