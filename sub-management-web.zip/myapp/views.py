# myapp/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status,permissions
from rest_framework.authentication import BaseAuthentication
from rest_framework.permissions import IsAuthenticated 
from rest_framework.exceptions import AuthenticationFailed

from django.db import connection, IntegrityError
import json
from datetime import date, datetime
import calendar

from .auth_utils import hash_password, check_password, generate_jwt_token, decode_jwt_token


def get_dict_from_row(cursor, row):
    if not row:
        return None
    columns = [col[0] for col in cursor.description]
    return dict(zip(columns, row))
class AuthenticatedUser:
    def __init__(self, user_data):
        self.id = user_data['id']
        self.username = user_data['username']
        self.email = user_data['email']
        
    @property
    def is_authenticated(self):
        return True

    def __str__(self):
        return self.username


class JWTAuthentication(BaseAuthentication):
    def authenticate(self, request):
        auth_header = request.META.get('HTTP_AUTHORIZATION')
        if not auth_header:
            return None 

        parts = auth_header.split()
        if parts[0].lower() != 'bearer' or len(parts) != 2:

            return None

        token = parts[1]
        try:
            payload = decode_jwt_token(token)
            user_id = payload.get('user_id')

            with connection.cursor() as cursor:
                cursor.execute("SELECT id, username, email FROM users WHERE id = %s", [user_id])
                user_row = cursor.fetchone()
                if not user_row:
                    raise AuthenticationFailed('کاربر یافت نشد.')

                columns = [col[0] for col in cursor.description]
                user_data = dict(zip(columns, user_row))

                return AuthenticatedUser(user_data), None # (user, auth)
        except ValueError as e:
            raise AuthenticationFailed(str(e)) 
        except Exception as e:
            raise AuthenticationFailed(f'احراز هویت توکن با شکست مواجه شد: {str(e)}')

    def authenticate_header(self, request):
        """
        برمی‌گرداند رشته‌ای که باید در هدر WWW-Authenticate شامل شود.
        این متد زمانی فراخوانی می‌شود که AuthenticationFailed رخ دهد.
        """
        return 'Bearer realm="api"'

# =======================================================
# 1. Auth (ورود و ثبت‌نام)
# =======================================================


class RegisterAPIView(APIView):
    def post(self, request):
        data = request.data
        username = data.get('username')
        email = data.get('email')
        password = data.get('password') 
        preferred_currency = data.get('preferred_currency')
        language = data.get('language')

        # --- لاگ‌های عیب‌یابی ---
        print(f"\n--- Register API Request ---")
        print(f"Received data: {data}")
        print(f"Username: {username}, Email: {email}, Password (first 5 chars): {password[:5] if password else 'N/A'}")
        # --- پایان لاگ‌ها ---

        if not all([username, email, password]):
            print("Validation failed: Missing username, email, or password.")
            return Response({'error': 'نام کاربری، ایمیل و رمز عبور اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        if '@' not in email or '.' not in email:
            print("Validation failed: Invalid email format.")
            return Response({'error': 'فرمت ایمیل نامعتبر است.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            password_hash = hash_password(password)
            print(f"Hashed password (first 10 chars): {password_hash[:10] if password_hash else 'N/A'}")
            if not password_hash: 
                 print("Error: hash_password returned an empty value.")
                 return Response({'error': 'خطا در هش کردن رمز عبور.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            with connection.cursor() as cursor:
                # --- لاگ برای کوئری ---
                print(f"Executing INSERT query for user: {username}")
                # --- پایان لاگ ---
                cursor.execute(
                    """
                    INSERT INTO users (username, email, password_hash, preferred_currency, language)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING id, username, email, password_hash, preferred_currency, language, created_at, updated_at;
                    """, # مطمئن شوید password_hash در RETURNING هم هست
                    [username, email, password_hash, preferred_currency, language]
                )
                new_user_row = cursor.fetchone()
                
                # --- لاگ برای نتیجه کوئری ---
                print(f"Query executed. Raw row: {new_user_row}")
                # --- پایان لاگ ---

                user_data = get_dict_from_row(cursor, new_user_row)
                
                # --- لاگ برای user_data بعد از تبدیل ---
                print(f"User data after dict conversion: {user_data}")
                # --- پایان لاگ ---

                if user_data:
                    # !!! نکته کلیدی: مطمئن شوید 'password_hash' هنوز در user_data وجود دارد!!!
                    # اگر خطای 'password_hash' در این نقطه (بعد از get_dict_from_row) رخ می‌دهد،
                    # یعنی یا در RETURNING نیست، یا get_dict_from_row آن را اشتباه می‌خواند.
                    if 'password_hash' not in user_data:
                        print("Error: 'password_hash' not found in user_data dictionary after database retrieval.")
                        return Response({'error': "خطای پایگاه داده: 'password_hash' در نتایج کوئری یافت نشد."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                    token = generate_jwt_token(user_data['id'])
                    
                    # این خط فقط باید در انتهای کار و قبل از ارسال پاسخ اجرا شود
                    # تا password_hash از پاسخ حذف شود
                    del user_data['password_hash']
                    
                    user_data['token'] = token
                    print("User registration successful. Returning response.")
                    return Response(user_data, status=status.HTTP_201_CREATED)
                
                print("Error: Failed to create user. No row returned from DB.")
                return Response({'error': 'ایجاد کاربر با شکست مواجه شد.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        except IntegrityError:
            print("IntegrityError: Username or Email already exists.")
            return Response({'error': 'نام کاربری یا ایمیل از قبل موجود است.'}, status=status.HTTP_409_CONFLICT)
        except Exception as e:
            print(f"Caught an unexpected exception: {e}")
            return Response({'error': f'خطای پایگاه داده: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
class LoginAPIView(APIView):
    def post(self, request):
        data = request.data
        identifier = data.get('identifier') # می‌تواند نام کاربری یا ایمیل باشد
        password = data.get('password')

        if not all([identifier, password]):
            return Response({'error': 'شناسه (نام کاربری/ایمیل) و رمز عبور اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT id, username, email, password_hash
                    FROM users
                    WHERE username = %s OR email = %s;
                    """,
                    [identifier, identifier]
                )
                user_row = cursor.fetchone()
                user_data = get_dict_from_row(cursor, user_row)

                if not user_data:
                    return Response({'error': 'اعتبارنامه‌ها نامعتبر هستند.'}, status=status.HTTP_401_UNAUTHORIZED)

                if check_password(password, user_data['password_hash']):
                    token = generate_jwt_token(user_data['id'])
                    del user_data['password_hash'] # حذف هش از پاسخ
                    user_data['token'] = token
                    return Response({'message': 'ورود با موفقیت انجام شد!', 'user': user_data}, status=status.HTTP_200_OK)
                else:
                    return Response({'error': 'اعتبارنامه‌ها نامعتبر هستند.'}, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response({'error': f'خطای سرور داخلی رخ داد: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class UserProfileAPIView(APIView):
    authentication_classes = [JWTAuthentication] # استفاده از کلاس احراز هویت JWT
    permission_classes = [permissions.IsAuthenticated] # فقط کاربران احراز هویت شده

    def get(self, request):
        user_info = {
            'id': request.user.id,
            'username': request.user.username,
            'email': request.user.email,
            'message': 'شما احراز هویت شده‌اید و می‌توانید به پروفایل خود دسترسی داشته باشید.'
        }
        return Response(user_info, status=status.HTTP_200_OK)

# =======================================================
# 2. Subscription (اشتراک‌ها)
# =======================================================

class SubscriptionListCreateAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user_id = request.user.id
        subscriptions = []
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT DISTINCT s.id, s.user_id, s.category_id, s.name, s.amount, s.currency, s.billing_cycle,
                s.next_payment_date, s.start_date, s.end_date, s.notes, s.is_shared, s.created_at, s.updated_at
                FROM subscriptions s
                LEFT JOIN shared_subscriptions ss ON s.id = ss.subscription_id
                WHERE s.user_id = %s OR ss.user_id = %s;
                    """,
                [user_id,user_id]
            )
            rows = cursor.fetchall()
            for row in rows:
                subscriptions.append(get_dict_from_row(cursor, row))
        
        return Response(subscriptions, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data
        user_id = request.user.id
        category_id = data.get('category_id')
        name = data.get('name')
        amount = data.get('amount')
        currency = data.get('currency')
        billing_cycle = data.get('billing_cycle')
        next_payment_date = data.get('next_payment_date')
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        notes = data.get('notes', '')
        is_shared = data.get('is_shared', False)

        if not all([name, amount, currency, billing_cycle]):
            return Response({'error': 'نام، مبلغ، ارز و چرخه صورتحساب اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        # اعتبارسنجی ساده تاریخ (می‌تواند قوی‌تر باشد)
        try:
            if next_payment_date: next_payment_date = date.fromisoformat(next_payment_date)
            if start_date: start_date = date.fromisoformat(start_date)
            if end_date: end_date = date.fromisoformat(end_date)
        except ValueError:
            return Response({'error': 'فرمت تاریخ نامعتبر است. از YYYY-MM-DD استفاده کنید.'}, status=status.HTTP_400_BAD_REQUEST)

        # اعتبارسنجی وجود category_id برای کاربر
        if category_id:
            with connection.cursor() as cursor:
                cursor.execute("SELECT id FROM categories WHERE id = %s AND user_id = %s;", [category_id, user_id])
                if not cursor.fetchone():
                    return Response({'error': 'دسته بندی یافت نشد یا غیرمجاز است.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO subscriptions (user_id, category_id, name, amount, currency, billing_cycle,
                                               next_payment_date, start_date, end_date, notes, is_shared)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id, user_id, category_id, name, amount, currency, billing_cycle,
                              next_payment_date, start_date, end_date, notes, is_shared, created_at, updated_at;
                    """,
                    [user_id, category_id, name, amount, currency, billing_cycle,
                     next_payment_date, start_date, end_date, notes, is_shared]
                )
                new_sub_row = cursor.fetchone()
                subscription_data = get_dict_from_row(cursor, new_sub_row)
                return Response(subscription_data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در ایجاد اشتراک: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class SubscriptionDetailAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get_subscription_object(self, sub_id, user_id):
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT id, user_id, category_id, name, amount, currency, billing_cycle,
                       next_payment_date, start_date, end_date, notes, is_shared, created_at, updated_at
                FROM subscriptions
                WHERE id = %s AND user_id = %s;
                """,
                [sub_id, user_id]
            )
            return get_dict_from_row(cursor, cursor.fetchone())

    def get(self, request, pk):
        subscription = self.get_subscription_object(pk, request.user.id)
        if not subscription:
            return Response({'error': 'اشتراک یافت نشد یا غیرمجاز است.'}, status=status.HTTP_404_NOT_FOUND)
        return Response(subscription, status=status.HTTP_200_OK)

    def put(self, request, pk):
        data = request.data
        user_id = request.user.id
        
        subscription = self.get_subscription_object(pk, user_id)
        if not subscription:
            return Response({'error': 'اشتراک یافت نشد یا غیرمجاز است.'}, status=status.HTTP_404_NOT_FOUND)
        
        # ساخت کوئری UPDATE به صورت پویا برای فیلدهای ارائه شده
        set_clauses = []
        params = []

        # لیستی از فیلدهای قابل به‌روزرسانی، به استثنای id، user_id و فیلدهای زمانی
        updatable_fields = ['category_id', 'name', 'amount', 'currency', 'billing_cycle',
                            'next_payment_date', 'start_date', 'end_date', 'notes', 'is_shared']
        
        for field in updatable_fields:
            if field in data:
                # مدیریت نوع داده Boolean برای SQL صحیح
                if field == 'is_shared':
                    set_clauses.append(f"{field} = %s")
                    params.append(bool(data[field]))
                # مدیریت تاریخ‌ها
                elif field in ['next_payment_date', 'start_date', 'end_date'] and data[field] is not None:
                    try:
                        params.append(date.fromisoformat(data[field]))
                        set_clauses.append(f"{field} = %s")
                    except ValueError:
                        return Response({'error': f'فرمت تاریخ {field} نامعتبر است. از YYYY-MM-DD استفاده کنید.'}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    set_clauses.append(f"{field} = %s")
                    params.append(data[field])

        if not set_clauses:
            return Response({'message': 'هیچ فیلدی برای به‌روزرسانی وجود ندارد.'}, status=status.HTTP_200_OK)
        
        # اعتبارسنجی category_id اگر ارائه شده باشد
        if 'category_id' in data and data['category_id'] is not None:
            with connection.cursor() as cursor:
                cursor.execute("SELECT id FROM categories WHERE id = %s AND user_id = %s;", [data['category_id'], user_id])
                if not cursor.fetchone():
                    return Response({'error': 'دسته بندی یافت نشد یا غیرمجاز است.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                params.append(pk) # اضافه کردن ID اشتراک برای شرط WHERE
                params.append(user_id) # اضافه کردن ID کاربر برای شرط WHERE (اطمینان از مالکیت)

                cursor.execute(
                    f"""
                    UPDATE subscriptions
                    SET {', '.join(set_clauses)}, updated_at = CURRENT_TIMESTAMP
                    WHERE id = %s AND user_id = %s
                    RETURNING id, user_id, category_id, name, amount, currency, billing_cycle,
                              next_payment_date, start_date, end_date, notes, is_shared, created_at, updated_at;
                    """,
                    params
                )
                updated_sub_row = cursor.fetchone()
                updated_subscription = get_dict_from_row(cursor, updated_sub_row)

                if updated_subscription:
                    return Response(updated_subscription, status=status.HTTP_200_OK)
                return Response({'error': 'به‌روزرسانی اشتراک با شکست مواجه شد. ممکن است وجود نداشته باشد یا شما مجاز نیستید.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در به‌روزرسانی اشتراک: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, pk):
        user_id = request.user.id
        
        subscription = self.get_subscription_object(pk, user_id)
        if not subscription:
            return Response({'error': 'اشتراک یافت نشد یا غیرمجاز است.'}, status=status.HTTP_404_NOT_FOUND)

        try:
            with connection.cursor() as cursor:
                # نکته مهم: ابتدا باید اشتراک‌های مشترک و پرداخت‌های مربوط به این اشتراک را حذف کنید.
                # یا مطمئن شوید که در schema دیتابیس خود CASCADE DELETE تنظیم شده است.
                # برای سادگی، ما اینجا آن‌ها را حذف می‌کنیم.
                
                cursor.execute("DELETE FROM shared_subscriptions WHERE subscription_id = %s;", [pk])
                cursor.execute("DELETE FROM payments WHERE subscription_id = %s;", [pk])
                cursor.execute("DELETE FROM shared_payments WHERE subscription_id = %s;", [pk])

                cursor.execute(
                    "DELETE FROM subscriptions WHERE id = %s AND user_id = %s;",
                    [pk, user_id]
                )
                if cursor.rowcount > 0:
                    return Response(status=status.HTTP_204_NO_CONTENT) # 204 No Content برای حذف موفق
                return Response({'error': 'اشتراک یافت نشد یا برای حذف مجاز نیستید.'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در حذف اشتراک: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# =======================================================
# 3. Shared Subscriptions (اشتراک‌های مشترک)
# =======================================================

# myapp/views.py

# ... (کدهای موجود شما) ...

class SharedSubscriptionAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk): # <--- متد GET جدید برای دریافت شرکا
        """
        نمایش لیست شرکای یک اشتراک مشترک خاص.
        فقط مالک اشتراک یا خود شریک می‌تواند لیست را ببیند.
        """
        user_id = request.user.id
        subscription_id = pk
        partners_data = []

        try:
            with connection.cursor() as cursor:
                # 1. مطمئن شوید اشتراک وجود دارد و کاربر فعلی مالک یا شریک آن است
                cursor.execute(
                    """
                    SELECT s.id
                    FROM subscriptions s
                    LEFT JOIN shared_subscriptions ss ON s.id = ss.subscription_id
                    WHERE s.id = %s AND (s.user_id = %s OR ss.user_id = %s);
                    """,
                    [subscription_id, user_id, user_id]
                )
                if not cursor.fetchone():
                    return Response({'error': 'اشتراک یافت نشد یا شما مجاز نیستید.'}, status=status.HTTP_404_NOT_FOUND)
                
                # 2. دریافت لیست شرکا برای این اشتراک
                cursor.execute(
                    """
                    SELECT ss.user_id, u.username, u.email, ss.share_ratio, ss.is_owner
                    FROM shared_subscriptions ss
                    JOIN users u ON ss.user_id = u.id
                    WHERE ss.subscription_id = %s;
                    """,
                    [subscription_id]
                )
                rows = cursor.fetchall()
                for row in rows:
                    partners_data.append({
                        'user_id': row[0],
                        'username': row[1],
                        'email': row[2],
                        'share_ratio': float(row[3]),
                        'is_owner': row[4]
                    })
            return Response(partners_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در دریافت شرکا: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    # ... (بقیه متدهای post, put, delete در همین کلاس) ...
    def post(self, request):
        # اضافه کردن یک شریک به اشتراک (کاربر فعلی باید مالک باشد)
        data = request.data
        owner_user_id = request.user.id # کاربر احراز هویت شده فعلی مالک است
        
        subscription_id = data.get('subscription_id')
        partner_identifier = data.get('partner_identifier') # نام کاربری یا ایمیل شریک
        share_ratio = data.get('share_ratio')
        is_owner_partner = data.get('is_owner', False) # آیا شریک جدید مالک است؟ (معمولاً false)

        if not all([subscription_id, partner_identifier, share_ratio is not None]):
            return Response({'error': 'subscription_id، partner_identifier و share_ratio اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        # اعتبارسنجی share_ratio (بین 0 تا 1)
        try:
            share_ratio = float(share_ratio)
            if not (0 <= share_ratio <= 1):
                return Response({'error': 'share_ratio باید بین 0 و 1 باشد.'}, status=status.HTTP_400_BAD_REQUEST)
        except ValueError:
            return Response({'error': 'share_ratio نامعتبر است.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                # 1. مطمئن شوید اشتراک وجود دارد و کاربر فعلی (owner_user_id) مالک آن است
                cursor.execute("SELECT id, is_shared FROM subscriptions WHERE id = %s AND user_id = %s;", [subscription_id, owner_user_id])
                sub_row = cursor.fetchone()
                if not sub_row:
                    return Response({'error': 'اشتراک یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
                
                # اگر اشتراک هنوز مشترک نیست، آن را به اشتراک‌گذاری شده تغییر دهید
                if not sub_row[1]: # is_shared is at index 1
                    cursor.execute("UPDATE subscriptions SET is_shared = TRUE WHERE id = %s;", [subscription_id])

                # 2. پیدا کردن ID کاربر شریک
                cursor.execute("SELECT id FROM users WHERE username = %s OR email = %s;", [partner_identifier, partner_identifier])
                partner_user_row = cursor.fetchone()
                if not partner_user_row:
                    return Response({'error': 'کاربر شریک یافت نشد.'}, status=status.HTTP_404_NOT_FOUND)
                partner_user_id = partner_user_row[0]

                if partner_user_id == owner_user_id:
                    return Response({'error': 'نمی‌توانید خودتان را به عنوان شریک اضافه کنید. شما مالک هستید.'}, status=status.HTTP_400_BAD_REQUEST)

                # 3. افزودن کاربر شریک به shared_subscriptions
                # بررسی کنید که آیا این شریک از قبل اضافه شده است یا خیر
                cursor.execute("SELECT * FROM shared_subscriptions WHERE subscription_id = %s AND user_id = %s;", [subscription_id, partner_user_id])
                if cursor.fetchone():
                    return Response({'error': 'این کاربر از قبل به عنوان شریک برای این اشتراک اضافه شده است.'}, status=status.HTTP_409_CONFLICT)

                cursor.execute(
                    """
                    INSERT INTO shared_subscriptions (subscription_id, user_id, share_ratio, is_owner)
                    VALUES (%s, %s, %s, %s)
                    RETURNING subscription_id, user_id, share_ratio, is_owner;
                    """,
                    [subscription_id, partner_user_id, share_ratio, is_owner_partner]
                )
                new_shared_sub_row = cursor.fetchone()
                shared_sub_data = get_dict_from_row(cursor, new_shared_sub_row)
                return Response(shared_sub_data, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در افزودن شریک: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, pk):
        # حذف یک کاربر شریک از اشتراک
        # PK اینجا subscription_id است و partner_user_id باید در بدنه درخواست باشد
        data = request.data
        owner_user_id = request.user.id # مالک باید حذف کند
        subscription_id = pk
        partner_identifier = data.get('partner_identifier') # نام کاربری یا ایمیل شریک برای حذف

        if not partner_identifier:
            return Response({'error': 'partner_identifier اجباری است.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                # 1. مطمئن شوید اشتراک وجود دارد و کاربر فعلی (owner_user_id) مالک آن است
                cursor.execute("SELECT id FROM subscriptions WHERE id = %s AND user_id = %s;", [subscription_id, owner_user_id])
                if not cursor.fetchone():
                    return Response({'error': 'اشتراک یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
                
                # 2. پیدا کردن ID کاربر شریک
                cursor.execute("SELECT id FROM users WHERE username = %s OR email = %s;", [partner_identifier, partner_identifier])
                partner_user_row = cursor.fetchone()
                if not partner_user_row:
                    return Response({'error': 'کاربر شریک یافت نشد.'}, status=status.HTTP_404_NOT_FOUND)
                partner_user_id = partner_user_row[0]

                # 3. حذف کاربر شریک
                cursor.execute(
                    "DELETE FROM shared_subscriptions WHERE subscription_id = %s AND user_id = %s;",
                    [subscription_id, partner_user_id]
                )
                if cursor.rowcount > 0:
                    return Response(status=status.HTTP_204_NO_CONTENT)
                return Response({'error': 'شریک برای این اشتراک یافت نشد.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در حذف شریک: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def put(self, request, pk):
        # ویرایش نسبت پرداخت یک شریک
        data = request.data
        owner_user_id = request.user.id
        subscription_id = pk
        partner_identifier = data.get('partner_identifier')
        share_ratio = data.get('share_ratio')

        if not all([partner_identifier, share_ratio is not None]):
            return Response({'error': 'partner_identifier و share_ratio اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            share_ratio = float(share_ratio)
            if not (0 <= share_ratio <= 1):
                return Response({'error': 'share_ratio باید بین 0 و 1 باشد.'}, status=status.HTTP_400_BAD_REQUEST)
        except ValueError:
            return Response({'error': 'share_ratio نامعتبر است.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                # 1. مطمئن شوید اشتراک وجود دارد و کاربر فعلی (owner_user_id) مالک آن است
                cursor.execute("SELECT id FROM subscriptions WHERE id = %s AND user_id = %s;", [subscription_id, owner_user_id])
                if not cursor.fetchone():
                    return Response({'error': 'اشتراک یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
                
                # 2. پیدا کردن ID کاربر شریک
                cursor.execute("SELECT id FROM users WHERE username = %s OR email = %s;", [partner_identifier, partner_identifier])
                partner_user_row = cursor.fetchone()
                if not partner_user_row:
                    return Response({'error': 'کاربر شریک یافت نشد.'}, status=status.HTTP_404_NOT_FOUND)
                partner_user_id = partner_user_row[0]

                # 3. به‌روزرسانی share_ratio
                cursor.execute(
                    """
                    UPDATE shared_subscriptions
                    SET share_ratio = %s
                    WHERE subscription_id = %s AND user_id = %s
                    RETURNING subscription_id, user_id, share_ratio, is_owner;
                    """,
                    [share_ratio, subscription_id, partner_user_id]
                )
                updated_row = cursor.fetchone()
                if updated_row:
                    updated_data = get_dict_from_row(cursor, updated_row)
                    return Response(updated_data, status=status.HTTP_200_OK)
                return Response({'error': 'شریک یا اشتراک مشترک یافت نشد.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در به‌روزرسانی نسبت پرداخت: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# =======================================================
# 4. Payments (پرداخت‌ها)
# =======================================================

class PaymentAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        # ثبت پرداخت کامل (برای مالک اشتراک)
        data = request.data
        user_id = request.user.id # کاربری که پرداخت را ثبت می‌کند
        subscription_id = data.get('subscription_id')
        amount = data.get('amount')
        currency = data.get('currency')
        payment_date_str = data.get('payment_date')
        status_text = data.get('status', 'paid') # وضعیت پیش‌فرض

        if not all([subscription_id, amount, currency, payment_date_str]):
            return Response({'error': 'subscription_id، amount، currency و payment_date اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            payment_date = date.fromisoformat(payment_date_str)
            amount = float(amount)
        except ValueError:
            return Response({'error': 'amount یا payment_date نامعتبر است.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            with connection.cursor() as cursor:
                # 1. اطمینان از اینکه اشتراک وجود دارد و کاربر فعلی مالک آن است
                cursor.execute("SELECT id FROM subscriptions WHERE id = %s AND user_id = %s;", [subscription_id, user_id])
                if not cursor.fetchone():
                    return Response({'error': 'اشتراک یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
                
                # 2. ثبت پرداخت
                cursor.execute(
                    """
                    INSERT INTO payments (subscription_id, amount, currency, payment_date, status)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING id, subscription_id, amount, currency, payment_date, status;
                    """,
                    [subscription_id, amount, currency, payment_date, status_text]
                )
                new_payment_row = cursor.fetchone()
                payment_data = get_dict_from_row(cursor, new_payment_row)
                return Response(payment_data, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در ثبت پرداخت: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class SharedPaymentAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        # ثبت پرداخت دنگی (توسط یک شریک)
        data = request.data
        payer_user_id = request.user.id # کاربری که پرداخت را ثبت می‌کند
        subscription_id = data.get('subscription_id')
        amount_paid = data.get('amount_paid')
        paid_at_str = data.get('paid_at', datetime.utcnow().isoformat()) # زمان پیش‌فرض: الان

        if not all([subscription_id, amount_paid is not None]):
            return Response({'error': 'subscription_id و amount_paid اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            amount_paid = float(amount_paid)
            paid_at = datetime.fromisoformat(paid_at_str.replace('Z', '+00:00')) # مدیریت 'Z' برای UTC
        except ValueError:
            return Response({'error': 'amount_paid یا paid_at نامعتبر است.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            with connection.cursor() as cursor:
                # 1. اطمینان از اینکه اشتراک وجود دارد و کاربر فعلی یک شریک (یا مالک) آن است
                cursor.execute(
                    """
                    SELECT s.id
                    FROM subscriptions s
                    LEFT JOIN shared_subscriptions ss ON s.id = ss.subscription_id
                    WHERE s.id = %s AND (s.user_id = %s OR ss.user_id = %s);
                    """,
                    [subscription_id, payer_user_id, payer_user_id]
                )
                if not cursor.fetchone():
                    return Response({'error': 'اشتراک یافت نشد یا شما شریک/مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
                
                # 2. ثبت پرداخت دنگی
                cursor.execute(
                    """
                    INSERT INTO shared_payments (subscription_id, user_id, amount_paid, paid_at)
                    VALUES (%s, %s, %s, %s)
                    RETURNING id, subscription_id, user_id, amount_paid, paid_at;
                    """,
                    [subscription_id, payer_user_id, amount_paid, paid_at]
                )
                new_shared_payment_row = cursor.fetchone()
                shared_payment_data = get_dict_from_row(cursor, new_shared_payment_row)
                return Response(shared_payment_data, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در ثبت پرداخت مشترک: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# =======================================================
# 5. Reports (گزارش‌ها)
# =======================================================
class CategoryReportAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user_id = request.user.id
        year = request.query_params.get('year')
        month = request.query_params.get('month')

        if not all([year, month]):
            return Response({'error': 'هر دو پارامتر year و month اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            year = int(year)
            month = int(month)
            if not (1 <= month <= 12):
                raise ValueError
        except ValueError:
            return Response({'error': 'مقادیر year و month نامعتبر هستند.'}, status=status.HTTP_400_BAD_REQUEST)

        report_data = []
        try:
            with connection.cursor() as cursor:
                
                cursor.execute(
                    """
                    SELECT c.name AS category_name, SUM(s.amount) AS total_amount, s.currency
                    FROM subscriptions s
                    JOIN categories c ON s.category_id = c.id
                    WHERE s.user_id = %s
                    AND EXTRACT(YEAR FROM s.next_payment_date) = %s
                    AND EXTRACT(MONTH FROM s.next_payment_date) = %s
                    GROUP BY c.name, s.currency
                    ORDER BY c.name;
                    """,
                    [user_id, year, month]
                )
                rows = cursor.fetchall()
                for row in rows:
                    report_data.append({
                        'category_name': row[0],
                        'total_amount': float(row[1]), # اطمینان از اینکه مقدار float است
                        'currency': row[2],
                    })
                return Response(report_data, status=status.HTTP_200_OK)
                
        except Exception as e:
            return Response({'error': f'خطا در گزارش هزینه بر اساس دسته‌بندی: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
# myapp/views.py



class MonthlyExpenseReportAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user_id = request.user.id
        year = request.query_params.get('year')
        month = request.query_params.get('month')


        print(f"\n--- Monthly Expense Report Request ---")
        print(f"User ID: {user_id}, Year: {year}, Month: {month}")

        if not all([year, month]):
            return Response({'error': 'پارامترهای year و month اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            year = int(year)
            month = int(month)
            if not (1 <= month <= 12):
                raise ValueError
        except ValueError:
            return Response({'error': 'سال و ماه نامعتبر هستند.'}, status=status.HTTP_400_BAD_REQUEST)

        report_data = {}
        total_monthly_expense = 0.0 # پیش‌فرض صفر

        with connection.cursor() as cursor:

            sql_query = """
            SELECT COALESCE(SUM(amount), 0.00) AS total_amount_sum
            FROM subscriptions
            WHERE user_id = %s
            AND EXTRACT(YEAR FROM next_payment_date) = %s
            AND EXTRACT(MONTH FROM next_payment_date) = %s;
            """
            query_params = [user_id, year, month]
            
            print(f"Executing SQL: {sql_query.strip()} with params: {query_params}")

            cursor.execute(sql_query, query_params)
            
            sum_result = cursor.fetchone() 
            
            print(f"Raw SUM result from DB: {sum_result}")

            total_monthly_expense = float(sum_result[0])

            report_data['personal_expenses'] = [] 
            report_data['owner_shared_expenses'] = []
            report_data['partner_shared_expenses'] = []
            
            report_data['total_estimated_monthly_expense'] = total_monthly_expense

        print(f"Calculated total_monthly_expense: {total_monthly_expense}")
        return Response(report_data, status=status.HTTP_200_OK)


class DebtCreditReportAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user_id = request.user.id
        report = {}

        with connection.cursor() as cursor:

            cursor.execute(
                """
                SELECT SUM(s.amount * ss.share_ratio) AS total_share_amount, s.currency
                FROM subscriptions s
                JOIN shared_subscriptions ss ON s.id = ss.subscription_id
                WHERE ss.user_id = %s
                GROUP BY s.currency;
                """,
                [user_id]
            )
            total_shares_rows = cursor.fetchall()
            total_shares = {row[1]: float(row[0]) for row in total_shares_rows}

            # کل پرداخت‌های دنگی که کاربر انجام داده است
            cursor.execute(
                """
                SELECT SUM(amount_paid) AS total_paid_amount, s.currency
                FROM shared_payments sp
                JOIN subscriptions s ON sp.subscription_id = s.id
                WHERE sp.user_id = %s
                GROUP BY s.currency;
                """,
                [user_id]
            )
            total_paid_rows = cursor.fetchall()
            total_paid = {row[1]: float(row[0]) for row in total_paid_rows}

            debts = {}
            credits = {}

            # محاسبه بدهی/طلبی
            all_currencies = set(list(total_shares.keys()) + list(total_paid.keys()))

            for currency in all_currencies:
                share = total_shares.get(currency, 0.0)
                paid = total_paid.get(currency, 0.0)
                
                net_amount = share - paid
                
                if net_amount > 0:
                    debts[currency] = net_amount
                elif net_amount < 0:
                    credits[currency] = abs(net_amount)

            report['debts'] = debts
            report['credits'] = credits
            report['notes'] = "این گزارش ساده‌ای است که سهم شما از اشتراک‌های مشترک را با پرداخت‌های دنگی شما مقایسه می‌کند."

        return Response(report, status=status.HTTP_200_OK)


# =======================================================
# 6. Notifications (نوتیفیکیشن‌ها)
# =======================================================

class NotificationSettingAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        # تنظیم یادآوری جدید
        data = request.data
        user_id = request.user.id
        subscription_id = data.get('subscription_id')
        method = data.get('method') # مثلا 'email', 'sms', 'in-app'
        days_before = data.get('days_before')
        is_active = data.get('is_active', True)

        if not all([subscription_id, method, days_before is not None]):
            return Response({'error': 'subscription_id، method و days_before اجباری هستند.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            days_before = int(days_before)
            if days_before < 0: raise ValueError
        except ValueError:
            return Response({'error': 'days_before باید یک عدد صحیح مثبت باشد.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                # 1. اطمینان از اینکه اشتراک وجود دارد و کاربر فعلی مالک آن است
                cursor.execute("SELECT id FROM subscriptions WHERE id = %s AND user_id = %s;", [subscription_id, user_id])
                if not cursor.fetchone():
                    return Response({'error': 'اشتراک یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
                
                # 2. ثبت تنظیمات نوتیفیکیشن
                cursor.execute(
                    """
                    INSERT INTO notifications (user_id, subscription_id, method, days_before, is_active)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING id, user_id, subscription_id, method, days_before, is_active;
                    """,
                    [user_id, subscription_id, method, days_before, is_active]
                )
                new_notif_row = cursor.fetchone()
                notif_data = get_dict_from_row(cursor, new_notif_row)
                return Response(notif_data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در تنظیم نوتیفیکیشن: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get(self, request):
        # نمایش لیست یادآوری‌های کاربر
        user_id = request.user.id
        notifications = []
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT id, user_id, subscription_id, method, days_before, is_active
                FROM notifications
                WHERE user_id = %s;
                """,
                [user_id]
            )
            rows = cursor.fetchall()
            for row in rows:
                notifications.append(get_dict_from_row(cursor, row))
        return Response(notifications, status=status.HTTP_200_OK)

    def put(self, request, pk):
        # ویرایش یک یادآوری موجود
        data = request.data
        user_id = request.user.id
        
        # بررسی وجود نوتیفیکیشن و مالکیت
        with connection.cursor() as cursor:
            cursor.execute("SELECT id, user_id FROM notifications WHERE id = %s AND user_id = %s;", [pk, user_id])
            notif_row = cursor.fetchone()
            if not notif_row:
                return Response({'error': 'نوتیفیکیشن یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)

        set_clauses = []
        params = []
        updatable_fields = ['method', 'days_before', 'is_active']

        for field in updatable_fields:
            if field in data:
                if field == 'days_before':
                    try:
                        days_before_val = int(data[field])
                        if days_before_val < 0: raise ValueError
                        set_clauses.append(f"{field} = %s")
                        params.append(days_before_val)
                    except ValueError:
                        return Response({'error': 'days_before باید یک عدد صحیح مثبت باشد.'}, status=status.HTTP_400_BAD_REQUEST)
                elif field == 'is_active':
                    set_clauses.append(f"{field} = %s")
                    params.append(bool(data[field]))
                else:
                    set_clauses.append(f"{field} = %s")
                    params.append(data[field])

        if not set_clauses:
            return Response({'message': 'هیچ فیلدی برای به‌روزرسانی وجود ندارد.'}, status=status.HTTP_200_OK)

        try:
            with connection.cursor() as cursor:
                params.append(pk)
                params.append(user_id)
                cursor.execute(
                    f"""
                    UPDATE notifications
                    SET {', '.join(set_clauses)}
                    WHERE id = %s AND user_id = %s
                    RETURNING id, user_id, subscription_id, method, days_before, is_active;
                    """,
                    params
                )
                updated_row = cursor.fetchone()
                updated_notif = get_dict_from_row(cursor, updated_row)
                if updated_notif:
                    return Response(updated_notif, status=status.HTTP_200_OK)
                return Response({'error': 'به‌روزرسانی نوتیفیکیشن با شکست مواجه شد.'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در به‌روزرسانی نوتیفیکیشن: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, pk):
        # حذف یک یادآوری
        user_id = request.user.id
        
        # بررسی وجود نوتیفیکیشن و مالکیت
        with connection.cursor() as cursor:
            cursor.execute("SELECT id FROM notifications WHERE id = %s AND user_id = %s;", [pk, user_id])
            if not cursor.fetchone():
                return Response({'error': 'نوتیفیکیشن یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
        
        try:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM notifications WHERE id = %s AND user_id = %s;", [pk, user_id])
                if cursor.rowcount > 0:
                    return Response(status=status.HTTP_204_NO_CONTENT)
                return Response({'error': 'حذف نوتیفیکیشن با شکست مواجه شد.'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در حذف نوتیفیکیشن: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# 6.2 پردازش نوتیف‌هایی که باید ارسال شن (Background Job)
# این بخش معمولاً به عنوان یک وظیفه پس‌زمینه (مثلاً با Celery) یا یک Cron Job اجرا می‌شود
# و نه به عنوان یک endpoint API مستقیم. اما برای نمایش منطق، یک View ساده ارائه می‌شود.
class ProcessNotificationsAPIView(APIView):
    # این endpoint نیازی به احراز هویت کاربری خاصی ندارد،
    # بلکه باید توسط یک سیستم برنامه‌ریزی شده یا داخلی فراخوانی شود.
    # می‌توانید اینجا از یک کلید API داخلی یا IP محدود استفاده کنید.
    # برای پروژه دانشگاهی، فعلاً بدون احراز هویت خاص است.

    def get(self, request): # یا post
        notifications_to_send = []
        today = date.today()

        try:
            with connection.cursor() as cursor:
                # پیدا کردن نوتیفیکیشن‌هایی که قرار است امروز ارسال شوند
                # (next_payment_date - days_before = امروز)
                cursor.execute(
                    """
                    SELECT n.id, n.user_id, n.subscription_id, n.method, n.days_before, s.name AS subscription_name, s.next_payment_date
                    FROM notifications n
                    JOIN subscriptions s ON n.subscription_id = s.id
                    WHERE n.is_active = TRUE
                    AND s.next_payment_date - n.days_before * INTERVAL '1 day' = %s;
                    """,
                    [today]
                )
                rows = cursor.fetchall()
                for row in rows:
                    notif_data = get_dict_from_row(cursor, row)
                    notifications_to_send.append(notif_data)
                
                # در اینجا منطق واقعی ارسال نوتیفیکیشن (مثلاً ارسال ایمیل، SMS، push notification)
                # برای هر notif_data در لیست notifications_to_send قرار می‌گیرد.
                # این بخش بسته به متد نوتیفیکیشن (email, sms) پیاده‌سازی متفاوتی دارد.
                # برای سادگی، فقط لیست نوتیفیکیشن‌های آماده ارسال را برمی‌گردانیم.

                return Response({
                    'message': f'تعداد {len(notifications_to_send)} نوتیفیکیشن آماده پردازش هستند.',
                    'notifications': notifications_to_send
                }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'error': f'خطا در پردازش نوتیفیکیشن‌ها: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

# myapp/views.py
# ... (تمام import ها و توابع کمکی موجود شما) ...

# =======================================================
# بخش جدید: Categories (دسته‌بندی‌ها)
# =======================================================

class CategoryAPIView(APIView):
    authentication_classes = [JWTAuthentication] # استفاده از کلاس احراز هویت JWT
    permission_classes = [permissions.IsAuthenticated]       # فقط کاربران احراز هویت شده

    def get(self, request):
        """
        نمایش لیست دسته‌بندی‌های متعلق به کاربر احراز هویت شده.
        """
        user_id = request.user.id
        categories = []
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT id, user_id, name
                    FROM categories
                    WHERE user_id = %s;
                    """,
                    [user_id]
                )
                rows = cursor.fetchall()
                for row in rows:
                    categories.append(get_dict_from_row(cursor, row))
            return Response(categories, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در دریافت دسته‌بندی‌ها: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post(self, request):
        """
        ایجاد یک دسته‌بندی جدید برای کاربر احراز هویت شده.
        """
        data = request.data
        user_id = request.user.id # user_id از کاربر احراز هویت شده گرفته می‌شود
        name = data.get('name')

        if not name:
            return Response({'error': 'نام دسته‌بندی اجباری است.'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO categories (user_id, name)
                    VALUES (%s, %s)
                    RETURNING id, user_id, name;
                    """,
                    [user_id, name]
                )
                new_category_row = cursor.fetchone()
                category_data = get_dict_from_row(cursor, new_category_row)
                return Response(category_data, status=status.HTTP_201_CREATED)
        except IntegrityError:
            # اگر نام دسته‌بندی (برای همین کاربر) از قبل وجود داشته باشد (اگر UNIQUE باشد)
            return Response({'error': 'دسته‌بندی با این نام از قبل موجود است.'}, status=status.HTTP_409_CONFLICT)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در ایجاد دسته‌بندی: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def put(self, request, pk):
        """
        ویرایش یک دسته‌بندی موجود برای کاربر احراز هویت شده.
        """
        data = request.data
        user_id = request.user.id
        category_id = pk # ID دسته‌بندی از URL

        # بررسی وجود دسته‌بندی و مالکیت
        with connection.cursor() as cursor:
            cursor.execute("SELECT id FROM categories WHERE id = %s AND user_id = %s;", [category_id, user_id])
            if not cursor.fetchone():
                return Response({'error': 'دسته‌بندی یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)

        set_clauses = []
        params = []
        updatable_fields = ['name']

        for field in updatable_fields:
            if field in data:
                set_clauses.append(f"{field} = %s")
                params.append(data[field])

        if not set_clauses:
            return Response({'message': 'هیچ فیلدی برای به‌روزرسانی وجود ندارد.'}, status=status.HTTP_200_OK)

        try:
            with connection.cursor() as cursor:
                params.append(category_id) # ID دسته‌بندی برای شرط WHERE
                params.append(user_id) # ID کاربر برای شرط WHERE (اطمینان از مالکیت)

                cursor.execute(
                    f"""
                    UPDATE categories
                    SET {', '.join(set_clauses)}
                    WHERE id = %s AND user_id = %s
                    RETURNING id, user_id, name;
                    """,
                    params
                )
                updated_row = cursor.fetchone()
                updated_category = get_dict_from_row(cursor, updated_row)

                if updated_category:
                    return Response(updated_category, status=status.HTTP_200_OK)
                return Response({'error': 'به‌روزرسانی دسته‌بندی با شکست مواجه شد.'}, status=status.HTTP_400_BAD_REQUEST)
        except IntegrityError:
            # اگر نام دسته‌بندی (برای همین کاربر) تکراری شود
            return Response({'error': 'دسته‌بندی با این نام از قبل موجود است.'}, status=status.HTTP_409_CONFLICT)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در به‌روزرسانی دسته‌بندی: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, pk):
        """
        حذف یک دسته‌بندی موجود برای کاربر احراز هویت شده.
        """
        user_id = request.user.id
        category_id = pk # ID دسته‌بندی از URL

        # بررسی وجود دسته‌بندی و مالکیت
        with connection.cursor() as cursor:
            cursor.execute("SELECT id FROM categories WHERE id = %s AND user_id = %s;", [category_id, user_id])
            if not cursor.fetchone():
                return Response({'error': 'دسته‌بندی یافت نشد یا شما مالک آن نیستید.'}, status=status.HTTP_404_NOT_FOUND)
            
            # بررسی اینکه آیا این دسته‌بندی به اشتراک‌های موجود ارجاع داده شده است
            # اگر CASCADE DELETE در دیتابیس تنظیم نشده باشد، باید ابتدا اشتراک‌ها را به روز یا حذف کرد.
            cursor.execute("SELECT COUNT(*) FROM subscriptions WHERE category_id = %s;", [category_id])
            if cursor.fetchone()[0] > 0:
                return Response({'error': 'این دسته‌بندی به اشتراک‌هایی متصل است و قابل حذف نیست.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM categories WHERE id = %s AND user_id = %s;",
                    [category_id, user_id]
                )
                if cursor.rowcount > 0:
                    return Response(status=status.HTTP_204_NO_CONTENT) # 204 No Content برای حذف موفق
                return Response({'error': 'حذف دسته‌بندی با شکست مواجه شد.'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': f'خطای پایگاه داده در حذف دسته‌بندی: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)