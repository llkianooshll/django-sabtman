# myapp/auth_utils.py
import jwt
import bcrypt
import datetime
import time
from django.conf import settings # دسترسی به SECRET_KEY جنگو

def hash_password(password):
    """رمز عبور را با استفاده از bcrypt هش می‌کند."""
    # خط مشکل‌ساز احتمالاً اینجاست
    # password رو از رشته به بایت تبدیل می‌کنیم
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def check_password(password, hashed_password):
    """بررسی می‌کند که آیا یک رمز عبور ساده با یک هش ذخیره شده مطابقت دارد."""
    try:
        # اینجا هم باید پسورد رو از رشته به بایت تبدیل کنیم
        return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
    except ValueError:
        return False

def generate_jwt_token(user_id):
    """یک توکن JWT برای user ID داده شده تولید می‌کند."""
    payload = {
        'user_id': user_id,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1),  # توکن 1 روز دیگر منقضی می‌شود
        'iat': datetime.datetime.utcnow()  # زمان صدور توکن
    }
    # برای سادگی، از SECRET_KEY جنگو برای کدگذاری JWT استفاده می‌کنیم.
    # در محیط Production، بهتر است از یک JWT_SECRET_KEY جداگانه و قوی‌تر استفاده کنید.
    token = jwt.encode(payload, settings.SECRET_KEY, algorithm='HS256')
    return token

def decode_jwt_token(token):
    """یک توکن JWT را رمزگشایی می‌کند و payload را برمی‌گرداند یا خطا می‌دهد."""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256'])
        return payload
    except jwt.ExpiredSignatureError:
        raise ValueError("توکن منقضی شده است.")
    except jwt.InvalidTokenError:
        raise ValueError("توکن نامعتبر است.")