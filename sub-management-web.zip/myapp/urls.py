# myapp/urls.py
from django.urls import path
from .views import (
    RegisterAPIView, LoginAPIView, UserProfileAPIView,
    SubscriptionListCreateAPIView, SubscriptionDetailAPIView,
    SharedSubscriptionAPIView,
    PaymentAPIView, SharedPaymentAPIView,
    MonthlyExpenseReportAPIView, DebtCreditReportAPIView,
    CategoryReportAPIView, 
    NotificationSettingAPIView, ProcessNotificationsAPIView,CategoryAPIView
)

urlpatterns = [
    # 1. Auth (ورود و ثبت‌نام)
    path('auth/register/', RegisterAPIView.as_view(), name='register'),
    path('auth/login/', LoginAPIView.as_view(), name='login'),
    path('auth/profile/', UserProfileAPIView.as_view(), name='user-profile'), # منبع محافظت شده

    # 2. Subscription (اشتراک‌ها)
    path('subscriptions/', SubscriptionListCreateAPIView.as_view(), name='subscription-list-create'),
    path('subscriptions/<int:pk>/', SubscriptionDetailAPIView.as_view(), name='subscription-detail'),

    # 3. Shared Subscriptions (اشتراک‌های مشترک)
    path('shared-subscriptions/', SharedSubscriptionAPIView.as_view(), name='shared-subscription-add'),
    path('shared-subscriptions/<int:pk>/', SharedSubscriptionAPIView.as_view(), name='shared-subscription-update-delete'), # برای PUT و DELETE

    # 4. Payments (پرداخت‌ها)
    path('payments/', PaymentAPIView.as_view(), name='payment-create'),
    path('shared-payments/', SharedPaymentAPIView.as_view(), name='shared-payment-create'),

    # 5. Reports (گزارش‌ها)
    path('reports/monthly-expense/', MonthlyExpenseReportAPIView.as_view(), name='monthly-expense-report'),
    path('reports/debt-credit/', DebtCreditReportAPIView.as_view(), name='debt-credit-report'),
    path('reports/category-expense/', CategoryReportAPIView.as_view(), name='category-expense-report'), # این مسیر برای گزارش دسته‌بندی است

    # 6. Notifications (نوتیفیکیشن‌ها)
    path('notifications/', NotificationSettingAPIView.as_view(), name='notification-settings-list-create'),
    path('notifications/<int:pk>/', NotificationSettingAPIView.as_view(), name='notification-settings-detail-update-delete'),
    path('notifications/process/', ProcessNotificationsAPIView.as_view(), name='process-notifications'), # این یک endpoint مدیریتی است

    # دسته‌بندی‌ها (Categories)
    path('categories/', CategoryAPIView.as_view(), name='category-list-create'),
    path('categories/<int:pk>/', CategoryAPIView.as_view(), name='category-detail-update-delete'),
]